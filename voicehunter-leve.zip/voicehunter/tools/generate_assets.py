#!/usr/bin/env python3
"""Regenerates every texture and sound of the mod procedurally (numpy + Pillow + ffmpeg).
Run from the project root:  python3 tools/generate_assets.py"""
import os, subprocess, tempfile, wave
import numpy as np
from PIL import Image

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "voicehunter")
TEX = os.path.join(ROOT, "textures"); SND = os.path.join(ROOT, "sounds")
for d in ("entity", "gui", "misc"): os.makedirs(os.path.join(TEX, d), exist_ok=True)
os.makedirs(SND, exist_ok=True)
rng = np.random.default_rng(1337)

# ---------------------------------------------------------------- entity texture (64x64)
def box(img, u, v, w, h, d, face_fn):
    """Paints the 6 faces of a Minecraft box UV layout. face_fn(name, x0, y0, fw, fh)."""
    faces = {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d), "right": (u, v + d, d, h),
             "front": (u + d, v + d, w, h), "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}
    for n, (x, y, fw, fh) in faces.items(): face_fn(n, x, y, fw, fh)

tex = np.zeros((64, 64, 4), np.uint8); glow = np.zeros((64, 64, 4), np.uint8); glow[..., 3] = 255

def fill(arr, x, y, w, h, col, noise=0):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            n = int(rng.integers(-noise, noise + 1)) if noise else 0
            arr[yy, xx] = [max(0, min(255, c + n)) for c in col[:3]] + [255]

def head(n, x, y, w, h):
    fill(tex, x, y, w, h, (120, 116, 110), 8)             # pale, dead skin
    if n == "front":
        for ex in (x + 1, x + 5):                           # hollow eye sockets (2 px wide, 3 px tall)
            fill(tex, ex, y + 2, 2, 3, (4, 4, 5)); fill(glow, ex, y + 3, 2, 1, (255, 20, 20))
        fill(tex, x + 1, y + 6, 6, 2, (4, 4, 5))            # stretched mouth
        for k in range(0, 6, 2): fill(glow, x + 1 + k, y + 7, 1, 1, (200, 10, 10))
        for k in (x + 1, x + 6): fill(tex, k, y + 5, 1, 1, (20, 20, 22))   # tear streaks
    if n == "top": fill(tex, x, y, w, h, (18, 18, 20), 4)
def body(n, x, y, w, h):
    fill(tex, x, y, w, h, (14, 14, 17), 5)
    if n in ("front", "back"):
        for k in range(0, w, 2): fill(tex, x + k, y, 1, h, (24, 24, 28))          # worn suit stripes
        if n == "front": fill(tex, x + w // 2 - 1, y + 2, 2, h - 4, (8, 8, 9))   # dark seam
def arm(n, x, y, w, h):
    fill(tex, x, y, w, h, (16, 16, 19), 4)
    if n in ("front", "back", "left", "right") and h > 8: fill(tex, x, y + h - 5, w, 5, (150, 145, 135), 8)  # long pale fingers
def leg(n, x, y, w, h):
    fill(tex, x, y, w, h, (10, 10, 12), 4)
box(tex, 0, 0, 8, 9, 8, head); box(tex, 0, 20, 6, 20, 4, body)
box(tex, 32, 0, 2, 24, 2, arm); box(tex, 40, 0, 2, 24, 2, arm)
box(tex, 48, 0, 2, 18, 2, leg); box(tex, 56, 0, 2, 18, 2, leg)
Image.fromarray(tex, "RGBA").save(os.path.join(TEX, "entity", "voice_hunter.png"))
Image.fromarray(glow, "RGBA").save(os.path.join(TEX, "entity", "voice_hunter_eyes.png"))

# ---------------------------------------------------------------- gui icons (32x32)
def mic(color, slash):
    im = np.zeros((32, 32, 4), np.uint8)
    yy, xx = np.mgrid[0:32, 0:32]
    cap = (((xx - 16) / 5.5) ** 2 + ((yy - 10) / 8.0) ** 2 <= 1) | ((abs(xx - 16) <= 5) & (yy >= 10) & (yy <= 15))
    arc = (abs(np.hypot((xx - 16) / 9.0, (yy - 15) / 9.5) - 1) < 0.14) & (yy >= 15) & (yy <= 24)
    stem = (abs(xx - 16) <= 1) & (yy >= 24) & (yy <= 28); base = (abs(xx - 16) <= 5) & (yy >= 28) & (yy <= 29)
    m = cap | arc | stem | base
    im[m] = list(color) + [255]
    if slash:
        s = (abs((xx - 4) - (yy - 3)) <= 1) & (xx >= 4) & (xx <= 28); im[s] = [255, 60, 60, 255]
    return im
Image.fromarray(mic((235, 235, 235), False), "RGBA").save(os.path.join(TEX, "gui", "mic_on.png"))
Image.fromarray(mic((120, 120, 120), True), "RGBA").save(os.path.join(TEX, "gui", "mic_off.png"))
# mic_on is tinted red so it reads as "recording"
on = np.array(Image.open(os.path.join(TEX, "gui", "mic_on.png"))); on[..., 1] = (on[..., 1] * 0.35).astype(np.uint8); on[..., 2] = (on[..., 2] * 0.35).astype(np.uint8)
Image.fromarray(on, "RGBA").save(os.path.join(TEX, "gui", "mic_on.png"))

# ---------------------------------------------------------------- vignette (256x256, black with radial alpha)
yy, xx = np.mgrid[0:256, 0:256]; r = np.hypot((xx - 127.5) / 127.5, (yy - 127.5) / 127.5)
a = np.clip((r - 0.45) / 0.75, 0, 1) ** 1.6
v = np.zeros((256, 256, 4), np.uint8); v[..., 3] = (a * 255).astype(np.uint8)
Image.fromarray(v, "RGBA").save(os.path.join(TEX, "misc", "vignette.png"))

# ---------------------------------------------------------------- sounds
SR = 44100
def t(sec): return np.linspace(0, sec, int(SR * sec), endpoint=False)
def lp(x, k):  # one-pole low-pass
    y = np.zeros_like(x); s = 0.0
    for i, v in enumerate(x): s += k * (v - s); y[i] = s
    return y
def bp_noise(sec, lo, hi):
    n = rng.standard_normal(int(SR * sec)); f = np.fft.rfft(n); fr = np.fft.rfftfreq(len(n), 1 / SR)
    f[(fr < lo) | (fr > hi)] = 0; return np.fft.irfft(f, len(n))
def env(x, a, r):
    n = len(x); e = np.ones(n); na, nr = max(1, int(a * SR)), max(1, int(r * SR))
    e[:na] = np.linspace(0, 1, na); e[-nr:] = np.minimum(e[-nr:], np.linspace(1, 0, nr)); return x * e
def norm(x, peak=0.9): return x / (np.max(np.abs(x)) + 1e-9) * peak
def save(name, x):
    x = np.clip(x, -1, 1); pcm = (x * 32767).astype("<i2")
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f: p = f.name
    with wave.open(p, "wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", p, "-c:a", "libvorbis", "-q:a", "4", os.path.join(SND, name + ".ogg")], check=True)
    os.remove(p)

# breath: slow in/out filtered noise
x = np.concatenate([env(bp_noise(1.3, 300, 2500), 0.5, 0.6), np.zeros(int(SR * 0.2)), env(bp_noise(1.5, 200, 1800), 0.3, 0.9)])
save("hunter_breath", norm(x, 0.7))
# step: dull thud + dry crack
s = t(0.35); x = np.sin(2 * np.pi * 70 * s) * np.exp(-s * 18) + 0.4 * bp_noise(0.35, 800, 3000) * np.exp(-s * 35)
save("hunter_step", norm(x))
# growl: low saw with rough amplitude modulation
s = t(1.6); f0 = 55 + 12 * np.sin(2 * np.pi * 3 * s); ph = np.cumsum(f0) / SR
x = (2 * (ph % 1) - 1) * (0.6 + 0.4 * np.sign(np.sin(2 * np.pi * 28 * s))) ; x = lp(x, 0.08) + 0.15 * bp_noise(1.6, 100, 700)
save("hunter_growl", norm(env(x, 0.15, 0.6)))
# screech: rising dissonant sweep + noise
s = t(1.8); f = 500 + 2200 * (s / 1.8) ** 1.5 + 60 * np.sin(2 * np.pi * 37 * s); ph = np.cumsum(f) / SR
x = np.sin(2 * np.pi * ph) + 0.6 * np.sin(2 * np.pi * ph * 1.41) + 0.5 * bp_noise(1.8, 1500, 9000)
save("hunter_screech", norm(env(np.tanh(2.5 * x), 0.03, 0.5)))
# vanish: falling whoosh
s = t(1.0); x = bp_noise(1.0, 80, 4000) * np.exp(-s * 3) * np.sin(2 * np.pi * (40 + 200 * np.exp(-s * 4)) * s + 3)
save("hunter_vanish", norm(env(x + 0.3 * bp_noise(1.0, 100, 600) * np.exp(-s * 5), 0.01, 0.4)))
# whisper (3 variants): breathy syllables
for i in (1, 2, 3):
    parts = []
    for _ in range(int(rng.integers(3, 6))):
        d = float(rng.uniform(0.12, 0.3)); parts.append(env(bp_noise(d, 1800 + 400 * i, 6500), 0.04, 0.08)); parts.append(np.zeros(int(SR * rng.uniform(0.03, 0.12))))
    x = np.concatenate(parts); x = x + 0.4 * np.roll(x, int(SR * 0.013))
    save(f"hunter_whisper_{i}", norm(x, 0.8))
# hurt / death
s = t(0.7); f = 300 - 200 * s; x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-s * 4) + 0.3 * bp_noise(0.7, 200, 3000) * np.exp(-s * 6)
save("hunter_hurt", norm(np.tanh(2 * x)))
s = t(2.6); f = 220 * np.exp(-s * 0.9); x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-s * 1.2) + 0.3 * bp_noise(2.6, 100, 1500) * np.exp(-s * 1.5)
save("hunter_death", norm(np.tanh(2 * x)))
# heartbeat: lub-dub
def thump(f, d): s = t(d); return np.sin(2 * np.pi * f * s) * np.exp(-s * 22)
x = np.zeros(int(SR * 1.0)); a = thump(55, 0.25); b = 0.7 * thump(48, 0.25); x[:len(a)] += a; o = int(SR * 0.24); x[o:o + len(b)] += b
save("heartbeat", norm(x))
# drone: detuned low sines, slow swell
s = t(9.0); x = sum(np.sin(2 * np.pi * f * s + k) for k, f in enumerate((41.2, 41.9, 61.7, 82.6, 87.1))) / 5
x = x * (0.6 + 0.4 * np.sin(2 * np.pi * 0.11 * s)) + 0.05 * bp_noise(9.0, 60, 400)
save("drone", norm(env(x, 2.5, 3.5), 0.8))
# sting: dissonant cluster hit
s = t(2.2); x = sum(np.sin(2 * np.pi * f * s) for f in (233, 247, 466, 494, 739)) * np.exp(-s * 2.2) + 0.5 * bp_noise(2.2, 100, 2500) * np.exp(-s * 9)
save("sting", norm(np.tanh(1.5 * x / 4)))
print("assets ok")
