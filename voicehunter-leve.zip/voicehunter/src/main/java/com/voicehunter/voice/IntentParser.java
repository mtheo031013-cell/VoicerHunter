package com.voicehunter.voice;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Turns free-form recognised speech (Portuguese + English) into an {@link Intent}.
 * <p>
 * Speech recognisers make mistakes, so the matching is fuzzy: accents are removed and every word of
 * a phrase may differ by a few letters (Levenshtein). Longer phrases win over short ones, so
 * "fica parado" beats "para", and "vem comigo" beats "vem".
 * This class is pure Java (no Minecraft classes) so it can run on both sides and be unit tested.
 */
public final class IntentParser {

    /** Result of a successful match. */
    public record Match(Intent intent, float confidence, boolean negated, String normalizedText) {
    }

    private record Phrase(Intent intent, String[] words) {
    }

    private static final List<Phrase> PHRASES = new ArrayList<>();
    private static final Set<String> NEGATORS = Set.of("nao", "not", "dont", "never", "nunca", "nem");
    private static final Map<Intent, Intent> NEGATION = new EnumMap<>(Intent.class);

    private static final double WORD_MIN = 0.72;
    private static final double PHRASE_MIN = 0.78;

    private static void add(Intent intent, String... phrases) {
        for (String p : phrases) {
            PHRASES.add(new Phrase(intent, p.split(" ")));
        }
    }

    static {
        add(Intent.COME,
                "vem aqui", "vem ca", "vem", "venha", "venha aqui", "chega aqui", "chega mais", "aproxima",
                "aproxime se", "se aproxima", "aparece", "come here", "come", "come closer", "get over here",
                "vem pra ca", "vem para ca");
        add(Intent.STOP,
                "para", "pare", "para ai", "para de andar", "stop", "halt", "espera", "espere", "calma");
        add(Intent.RUN,
                "corre", "corra", "corre corre", "correr", "rapido", "mais rapido", "depressa", "anda logo",
                "run", "faster", "hurry");
        add(Intent.FOLLOW,
                "me segue", "me siga", "segue me", "siga me", "vem comigo", "anda comigo", "vamos", "segue",
                "follow me", "come with me", "follow");
        add(Intent.GO_AWAY,
                "vai embora", "va embora", "some", "sai daqui", "sai", "afasta", "afaste se", "vai pra longe",
                "vai para longe", "fora daqui", "go away", "leave", "get out", "leave me alone",
                "me deixa em paz", "deixa me em paz", "foge", "fuja", "vai la", "vai");
        add(Intent.STAY,
                "fica parado", "fique parado", "fica ai", "fique ai", "fica quieto", "fique quieto",
                "nao se mexa", "nao se mexe", "fica aqui", "fique aqui", "fica", "fique", "parado",
                "stay", "stay there", "freeze", "dont move", "stay still");
        add(Intent.SEARCH,
                "me procura", "me procure", "procura me", "procure me", "me encontra", "me encontre",
                "onde voce esta", "cade voce", "procura", "procure", "find me", "look for me", "search",
                "where are you", "seek");
        add(Intent.SLEEP,
                "dorme", "durma", "vai dormir", "hora de dormir", "descansa", "descanse", "boa noite",
                "sleep", "go to sleep", "rest", "good night", "dormir");
        add(Intent.WAKE,
                "acorda", "acorde", "desperta", "desperte", "levanta", "levante", "wake up", "wake", "get up");
        add(Intent.ATTACK,
                "me ataca", "me ataque", "ataca me", "vem me pegar", "me pega", "me pegue", "pega me",
                "vem me atacar", "attack me", "come get me", "catch me", "try to catch me", "me mata");
        add(Intent.GREET,
                "oi", "ola", "e ai", "bom dia", "boa tarde", "hello", "hi", "hey", "ei", "alo");
        add(Intent.PRAISE,
                "bom menino", "bom garoto", "muito bem", "boa", "legal", "obrigado", "obrigada", "valeu",
                "amigo", "gosto de voce", "desculpa", "desculpe", "perdao", "good boy", "thank you",
                "thanks", "friend", "sorry", "good job", "well done", "voce e legal");
        add(Intent.INSULT,
                "idiota", "burro", "feio", "lixo", "imbecil", "bobo", "otario", "estupido", "odeio voce",
                "cala a boca", "monstro feio", "porcaria", "stupid", "ugly", "idiot", "shut up", "hate you",
                "dumb", "loser", "burra", "feia", "chato");
        add(Intent.THREAT,
                "vou te matar", "vou te pegar", "morre", "morra", "vou te destruir", "vou te bater", "te mato",
                "vou te achar", "die", "kill you", "i will kill you", "vou acabar com voce", "te destruo",
                "lute", "luta", "briga comigo");
        add(Intent.HELP,
                "socorro", "ajuda", "me ajuda", "me ajude", "help", "help me", "alguem me ajuda", "ajudem");

        NEGATION.put(Intent.COME, Intent.GO_AWAY);
        NEGATION.put(Intent.FOLLOW, Intent.STAY);
        NEGATION.put(Intent.RUN, Intent.STOP);
        NEGATION.put(Intent.SEARCH, Intent.STAY);
        NEGATION.put(Intent.GO_AWAY, Intent.COME);
        NEGATION.put(Intent.STAY, Intent.COME);
        NEGATION.put(Intent.STOP, Intent.RUN);
        NEGATION.put(Intent.SLEEP, Intent.WAKE);
        NEGATION.put(Intent.WAKE, Intent.SLEEP);
        NEGATION.put(Intent.ATTACK, Intent.STOP);
    }

    private IntentParser() {
    }

    /** Applies "não" / "don't": "não vem aqui" becomes GO_AWAY. Tone intents are returned unchanged. */
    public static Intent resolveNegation(Match match) {
        if (!match.negated()) {
            return match.intent();
        }
        return NEGATION.getOrDefault(match.intent(), match.intent());
    }

    /** Lower-case, strip accents and punctuation, collapse whitespace. */
    public static String normalize(String raw) {
        if (raw == null) {
            return "";
        }
        String s = Normalizer.normalize(raw.toLowerCase(Locale.ROOT), Normalizer.Form.NFD);
        s = s.replaceAll("\\p{M}+", "");
        s = s.replaceAll("[^a-z0-9 ]", " ");
        s = s.replaceAll("\\s+", " ").trim();
        return s;
    }

    /** @return the best match or {@code null} if nothing resembles a known phrase. */
    public static Match parse(String raw) {
        String norm = normalize(raw);
        if (norm.isEmpty()) {
            return null;
        }
        String[] tokens = norm.split(" ");

        Match best = null;
        double bestWeight = 0.0;

        for (Phrase phrase : PHRASES) {
            int n = phrase.words().length;
            // single words are ambiguous inside long sentences ("eu vou para casa"), so only accept
            // them when the utterance is short.
            if (n == 1 && tokens.length > 4) {
                continue;
            }
            for (int i = 0; i + n <= tokens.length; i++) {
                double score = windowScore(tokens, i, phrase.words());
                if (score < PHRASE_MIN) {
                    continue;
                }
                double weight = score * (1.0 + 0.35 * (n - 1));
                if (n == tokens.length) {
                    weight += 0.15;
                }
                if (weight > bestWeight) {
                    bestWeight = weight;
                    boolean negated = i > 0 && NEGATORS.contains(tokens[i - 1]);
                    best = new Match(phrase.intent(), (float) Math.min(1.0, score), negated, norm);
                }
            }
        }
        return best;
    }

    private static double windowScore(String[] tokens, int start, String[] words) {
        double total = 0;
        for (int k = 0; k < words.length; k++) {
            double s = wordSimilarity(tokens[start + k], words[k]);
            if (s < WORD_MIN) {
                return 0;
            }
            total += s;
        }
        return total / words.length;
    }

    private static double wordSimilarity(String a, String b) {
        if (a.equals(b)) {
            return 1.0;
        }
        // short words must be exact, otherwise "vem" ~ "bem" ~ "em" would match everything
        if (a.length() <= 3 || b.length() <= 3) {
            return 0.0;
        }
        int max = Math.max(a.length(), b.length());
        int dist = levenshtein(a, b);
        return 1.0 - (double) dist / (double) max;
    }

    static int levenshtein(String a, String b) {
        int[] prev = new int[b.length() + 1];
        int[] cur = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) {
            prev[j] = j;
        }
        for (int i = 1; i <= a.length(); i++) {
            cur[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                cur[j] = Math.min(Math.min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + cost);
            }
            int[] t = prev;
            prev = cur;
            cur = t;
        }
        return prev[b.length()];
    }
}
