package com.voicehunter.voice;

import java.util.Locale;

/**
 * Everything the monster is able to "understand" from what the player says.
 * The first block are commands, the second block are emotional / tonal intents.
 */
public enum Intent {
    // --- commands ---
    COME,       // "vem aqui"
    STOP,       // "para"
    RUN,        // "corre"
    FOLLOW,     // "me segue"
    GO_AWAY,    // "vai embora"
    STAY,       // "fica parado"
    SEARCH,     // "me procura"
    SLEEP,      // "dorme"
    WAKE,       // "acorda"
    ATTACK,     // "vem me pegar"
    // --- tone ---
    GREET,      // "oi"
    PRAISE,     // "bom garoto", "desculpa"
    INSULT,     // "idiota"
    THREAT,     // "vou te matar"
    HELP;       // "socorro"

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public boolean isCommand() {
        return ordinal() <= ATTACK.ordinal();
    }

    public static Intent byOrdinal(int id) {
        Intent[] all = values();
        return id >= 0 && id < all.length ? all[id] : null;
    }
}
