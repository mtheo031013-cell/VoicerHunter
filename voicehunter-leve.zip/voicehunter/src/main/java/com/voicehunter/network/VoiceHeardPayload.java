package com.voicehunter.network;

import com.voicehunter.VoiceHunterMod;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Client -> server. The client recognised speech locally and tells the server WHAT was said
 * (text only, never audio). {@code text} is empty when only a voice/noise was detected.
 *
 * @param loudness 0..1 (1 = shouting)
 */
public record VoiceHeardPayload(String text, float loudness) implements CustomPacketPayload {
    public static final ResourceLocation ID = new ResourceLocation(VoiceHunterMod.MODID, "voice_heard");

    public VoiceHeardPayload(FriendlyByteBuf buf) {
        this(buf.readUtf(256), buf.readFloat());
    }

    @Override
    public void write(FriendlyByteBuf buf) {
        buf.writeUtf(text, 256);
        buf.writeFloat(loudness);
    }

    @Override
    public ResourceLocation id() {
        return ID;
    }
}
