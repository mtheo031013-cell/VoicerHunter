package com.voicehunter.network;

import com.voicehunter.VoiceHunterMod;
import com.voicehunter.server.VoiceBrain;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlerEvent;
import net.neoforged.neoforge.network.registration.IPayloadRegistrar;

/** Registers the two packets of the mod. */
public final class ModNetwork {

    public static void register(RegisterPayloadHandlerEvent event) {
        IPayloadRegistrar registrar = event.registrar(VoiceHunterMod.MODID).versioned("1");

        // client -> server: what the player said
        registrar.play(VoiceHeardPayload.ID, VoiceHeardPayload::new, handler -> handler
                .server((payload, ctx) -> ctx.workHandler().submitAsync(() ->
                        ctx.player().ifPresent(player -> {
                            if (player instanceof ServerPlayer serverPlayer) {
                                VoiceBrain.onVoice(serverPlayer, payload.text(), payload.loudness());
                            }
                        }))));

        // server -> client: how the monster reacted. The lambda body is only executed on the client,
        // so the client-only class is never loaded on a dedicated server.
        registrar.play(HunterFeedbackPayload.ID, HunterFeedbackPayload::new, handler -> handler
                .client((payload, ctx) -> ctx.workHandler().submitAsync(() ->
                        com.voicehunter.client.ClientHooks.onFeedback(payload))));
    }

    private ModNetwork() {
    }
}
