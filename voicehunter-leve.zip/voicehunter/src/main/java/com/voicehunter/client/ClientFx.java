package com.voicehunter.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.config.ClientConfig;
import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.VoiceHunterEntity;
import com.voicehunter.registry.ModSounds;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.level.material.FogType;
import net.neoforged.neoforge.client.event.ViewportEvent;
import net.neoforged.neoforge.client.gui.overlay.ExtendedGui;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Client-side atmosphere, driven only by the synced state of nearby monsters:
 * vignette, closing fog, heartbeat, camera shake and flashes when it appears or starts hunting.
 */
public final class ClientFx {

    private static final ResourceLocation VIGNETTE = new ResourceLocation(VoiceHunterMod.MODID, "textures/misc/vignette.png");

    private static float intensity;
    private static float shake;
    private static float flash;
    private static int flashRgb;
    private static int heartbeatCooldown;
    private static int scanCooldown;
    private static int glitchTicks;
    private static final int[] GLITCH_Y = new int[3];
    private static final Map<Integer, HunterState> LAST = new HashMap<>();

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        flash *= 0.82f;
        shake *= 0.9f;
        if (glitchTicks > 0) {
            glitchTicks--;
        }
        if (mc.level == null || mc.player == null || !ClientConfig.ATMOSPHERE.get()) {
            intensity *= 0.9f;
            return;
        }
        if (mc.isPaused()) {
            return;
        }

        float target = 0f;
        if (--scanCooldown <= 0) {
            scanCooldown = 3;
            List<VoiceHunterEntity> list = mc.level.getEntitiesOfClass(VoiceHunterEntity.class,
                    mc.player.getBoundingBox().inflate(48.0));
            Map<Integer, HunterState> seen = new HashMap<>();
            for (VoiceHunterEntity h : list) {
                HunterState s = h.getHunterState();
                HunterState prev = LAST.get(h.getId());
                seen.put(h.getId(), s);
                if (prev != null && prev != s) {
                    if (s == HunterState.HUNTING) {
                        flash(0xB01010, 0.55f);
                        shake = Math.max(shake, 1.0f);
                    } else if (prev == HunterState.VANISHED) {
                        flash(0x000000, 0.6f);
                    }
                }
                target = Math.max(target, weight(s) * Mth.clamp(1f - h.distanceTo(mc.player) / 38f, 0f, 1f));
                if (s == HunterState.HUNTING && h.distanceTo(mc.player) < 7f) {
                    shake = Math.max(shake, 0.5f);
                }
            }
            LAST.clear();
            LAST.putAll(seen);
            targetIntensity = target;
        }
        intensity += (targetIntensity - intensity) * 0.08f;

        if (intensity > 0.12f) {
            if (--heartbeatCooldown <= 0) {
                mc.getSoundManager().play(SimpleSoundInstance.forUI(ModSounds.HEARTBEAT.get(),
                        0.7f + 0.4f * intensity, 0.35f + 0.65f * intensity));
                heartbeatCooldown = (int) Mth.lerp(intensity, 46f, 14f);
            }
            if (intensity > 0.5f && mc.level.random.nextInt(70) == 0) {
                glitchTicks = 3;
                for (int i = 0; i < GLITCH_Y.length; i++) {
                    GLITCH_Y[i] = mc.level.random.nextInt(240);
                }
            }
            if (intensity > 0.35f && mc.level.random.nextInt(260) == 0) {
                flash(0x000000, 0.7f); // light flicker
            }
        }
    }

    private static float targetIntensity;

    private static float weight(HunterState s) {
        return switch (s) {
            case HUNTING -> 1.0f;
            case STALKING -> 0.8f;
            case COMING, RUNNING, FOLLOWING -> 0.6f;
            case SEARCHING -> 0.5f;
            case WATCHING -> 0.45f;
            case VANISHED -> 0f;
            default -> 0.25f;
        };
    }

    private static void flash(int rgb, float amount) {
        flashRgb = rgb;
        flash = Math.max(flash, amount);
    }

    // ------------------------------------------------------------------------------------------
    //  rendering
    // ------------------------------------------------------------------------------------------

    public static void renderOverlay(ExtendedGui gui, GuiGraphics g, float partialTick, int w, int h) {
        if (!ClientConfig.ATMOSPHERE.get()) {
            return;
        }
        if (intensity > 0.03f) {
            RenderSystem.enableBlend();
            g.setColor(1f, 0.6f, 0.6f, Math.min(0.9f, intensity * 0.95f));
            g.blit(VIGNETTE, 0, 0, w, h, 0, 0, 256, 256, 256, 256);
            g.setColor(1f, 1f, 1f, 1f);
            RenderSystem.disableBlend();
        }
        if (flash > 0.02f) {
            int a = (int) (Mth.clamp(flash, 0f, 1f) * 255f);
            g.fill(0, 0, w, h, (a << 24) | flashRgb);
        }
        if (glitchTicks > 0) {
            for (int y : GLITCH_Y) {
                int yy = y * h / 240;
                g.fill(0, yy, w, yy + 2 + (y % 5), 0x30FFFFFF);
            }
        }
    }

    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (shake < 0.02f || !ClientConfig.ATMOSPHERE.get()) {
            return;
        }
        var rnd = Minecraft.getInstance().level == null ? null : Minecraft.getInstance().level.random;
        if (rnd == null) {
            return;
        }
        event.setYaw(event.getYaw() + (rnd.nextFloat() - 0.5f) * shake * 2.0f);
        event.setPitch(event.getPitch() + (rnd.nextFloat() - 0.5f) * shake * 1.4f);
        event.setRoll(event.getRoll() + (rnd.nextFloat() - 0.5f) * shake * 3.0f);
    }

    public static void onFog(ViewportEvent.RenderFog event) {
        if (intensity < 0.05f || !ClientConfig.ATMOSPHERE.get() || event.getType() != FogType.NONE) {
            return;
        }
        float far = Mth.lerp(intensity, event.getFarPlaneDistance(), Math.min(event.getFarPlaneDistance(), 20f));
        event.setNearPlaneDistance(Mth.lerp(intensity, event.getNearPlaneDistance(), 0f));
        event.setFarPlaneDistance(far);
        event.setCanceled(true); // cancelling makes the game use our values
    }

    public static void onFogColor(ViewportEvent.ComputeFogColor event) {
        if (intensity < 0.05f || !ClientConfig.ATMOSPHERE.get()) {
            return;
        }
        float k = 1f - 0.7f * intensity;
        event.setRed(event.getRed() * (1f - 0.55f * intensity));
        event.setGreen(event.getGreen() * k * 0.8f);
        event.setBlue(event.getBlue() * k * 0.8f);
    }

    public static void reset() {
        intensity = 0f;
        targetIntensity = 0f;
        shake = 0f;
        flash = 0f;
        LAST.clear();
    }

    private ClientFx() {
    }
}
