package com.voicehunter.entity;

import java.util.Locale;

/** High level behaviour the monster is currently performing (synced to the client). */
public enum HunterState {
    IDLE,
    WATCHING,   // observes the player from far away
    STALKING,   // creeps closer, freezes when looked at
    COMING,     // "vem aqui"
    FOLLOWING,  // "me segue"
    RUNNING,    // "corre"
    FLEEING,    // "vai embora"
    FROZEN,     // "para" / "fica parado"
    SEARCHING,  // "me procura"
    SLEEPING,   // "dorme"
    HUNTING,    // aggressive
    VANISHED;   // invisible, about to reappear somewhere else

    public String key() {
        return name().toLowerCase(Locale.ROOT);
    }

    public static HunterState byId(int id) {
        HunterState[] all = values();
        return id >= 0 && id < all.length ? all[id] : IDLE;
    }
}
