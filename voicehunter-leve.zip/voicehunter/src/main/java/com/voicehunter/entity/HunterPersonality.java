package com.voicehunter.entity;

import com.voicehunter.voice.Intent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;

import java.util.EnumMap;
import java.util.Map;

/**
 * The monster's "mind". Every monster is born with slightly different traits, and its mood changes
 * with what the player says: insults raise aggression, praise builds trust, and so on.
 */
public final class HunterPersonality {

    /** What the monster decides to do with a command it understood. */
    public enum Outcome {
        OBEY, IGNORE, MISHEAR, PRETEND
    }

    // --- permanent traits (0..1) ---
    public float obedience = 0.6f;
    public float mischief = 0.4f;
    public float curiosity = 0.5f;
    public boolean fakeSleeper = false;

    // --- mood ---
    public float aggression = 0.0f;   // 0..1
    public float trust = 0.0f;        // -1..1

    public int commandsHeard = 0;

    private static final Map<Intent, Intent[]> CONFUSIONS = new EnumMap<>(Intent.class);

    static {
        CONFUSIONS.put(Intent.COME, new Intent[]{Intent.GO_AWAY, Intent.STAY, Intent.SEARCH, Intent.RUN});
        CONFUSIONS.put(Intent.STOP, new Intent[]{Intent.RUN, Intent.COME, Intent.ATTACK});
        CONFUSIONS.put(Intent.RUN, new Intent[]{Intent.STOP, Intent.COME, Intent.GO_AWAY});
        CONFUSIONS.put(Intent.FOLLOW, new Intent[]{Intent.COME, Intent.STAY, Intent.SEARCH});
        CONFUSIONS.put(Intent.GO_AWAY, new Intent[]{Intent.COME, Intent.FOLLOW, Intent.SEARCH});
        CONFUSIONS.put(Intent.STAY, new Intent[]{Intent.RUN, Intent.FOLLOW, Intent.COME});
        CONFUSIONS.put(Intent.SEARCH, new Intent[]{Intent.SLEEP, Intent.STAY, Intent.COME});
        CONFUSIONS.put(Intent.SLEEP, new Intent[]{Intent.RUN, Intent.STAY, Intent.SEARCH});
        CONFUSIONS.put(Intent.WAKE, new Intent[]{Intent.SLEEP, Intent.ATTACK});
        CONFUSIONS.put(Intent.ATTACK, new Intent[]{Intent.COME, Intent.FOLLOW});
    }

    public void randomize(RandomSource r) {
        obedience = 0.35f + r.nextFloat() * 0.45f;
        mischief = 0.2f + r.nextFloat() * 0.6f;
        curiosity = 0.25f + r.nextFloat() * 0.65f;
        fakeSleeper = r.nextFloat() < 0.4f;
    }

    /** Slow decay of the mood. Called once per tick. */
    public void tick() {
        if (aggression > 0) {
            aggression = Math.max(0f, aggression - 0.00012f);
        }
        if (trust > 0) {
            trust = Math.max(0f, trust - 0.00003f);
        } else if (trust < 0) {
            trust = Math.min(0f, trust + 0.00003f);
        }
    }

    public void addAggression(float amount) {
        aggression = Mth.clamp(aggression + amount, 0f, 1f);
    }

    public void addTrust(float amount) {
        trust = Mth.clamp(trust + amount, -1f, 1f);
    }

    /**
     * Decides how the monster reacts to a command it understood.
     *
     * @param confidence      how clearly the phrase matched (0..1)
     * @param disobedienceScale config multiplier (0 = always obeys, 2 = very rebellious)
     */
    public Outcome decide(RandomSource r, float confidence, float disobedienceScale) {
        float obey = Mth.clamp(obedience + 0.25f * trust - 0.40f * aggression, 0.03f, 0.97f);
        float dis = Mth.clamp((1f - obey) * disobedienceScale, 0f, 0.95f);

        float pIgnore = dis * 0.45f;
        float pMishear = dis * 0.30f + (1f - confidence) * 0.30f * Math.min(1f, disobedienceScale);
        float pPretend = dis * 0.25f + mischief * 0.06f * Math.min(1f, disobedienceScale);

        float sum = pIgnore + pMishear + pPretend;
        if (sum > 0.95f) {
            float k = 0.95f / sum;
            pIgnore *= k;
            pMishear *= k;
            pPretend *= k;
        }

        float x = r.nextFloat();
        if (x < pIgnore) {
            return Outcome.IGNORE;
        }
        x -= pIgnore;
        if (x < pMishear) {
            return Outcome.MISHEAR;
        }
        x -= pMishear;
        if (x < pPretend) {
            return Outcome.PRETEND;
        }
        return Outcome.OBEY;
    }

    /** Picks something the monster "misheard" instead of the real command. */
    public Intent confuse(Intent actual, RandomSource r) {
        Intent[] options = CONFUSIONS.get(actual);
        if (options == null || options.length == 0) {
            return actual;
        }
        return options[r.nextInt(options.length)];
    }

    public void save(CompoundTag tag) {
        tag.putFloat("VHObedience", obedience);
        tag.putFloat("VHMischief", mischief);
        tag.putFloat("VHCuriosity", curiosity);
        tag.putBoolean("VHFakeSleeper", fakeSleeper);
        tag.putFloat("VHAggression", aggression);
        tag.putFloat("VHTrust", trust);
        tag.putInt("VHCommands", commandsHeard);
    }

    public void load(CompoundTag tag) {
        if (tag.contains("VHObedience")) {
            obedience = tag.getFloat("VHObedience");
            mischief = tag.getFloat("VHMischief");
            curiosity = tag.getFloat("VHCuriosity");
            fakeSleeper = tag.getBoolean("VHFakeSleeper");
            aggression = tag.getFloat("VHAggression");
            trust = tag.getFloat("VHTrust");
            commandsHeard = tag.getInt("VHCommands");
        }
    }
}
