package com.voicehunter.registry;

import com.voicehunter.VoiceHunterMod;
import com.voicehunter.entity.VoiceHunterEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, VoiceHunterMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<VoiceHunterEntity>> VOICE_HUNTER =
            ENTITIES.register("voice_hunter", () ->
                    EntityType.Builder.of(VoiceHunterEntity::new, MobCategory.MONSTER)
                            .sized(0.6F, 2.9F)
                            .clientTrackingRange(10)
                            .updateInterval(2)
                            .build("voice_hunter"));

    private ModEntities() {
    }
}
