package com.voicehunter.server;

import com.voicehunter.config.CommonConfig;
import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.VoiceHunterEntity;
import com.voicehunter.registry.ModEntities;
import com.voicehunter.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.Difficulty;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.TickEvent;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The "game master" of the horror. For each player it
 * <ul>
 *     <li>decides when the monster shows up (attracted by the player's voice, or by the dark),</li>
 *     <li>plays random scary sounds that only that player hears,</li>
 *     <li>makes the monster's presence felt: torches go out, the light dims.</li>
 * </ul>
 */
public final class HauntDirector {

    private static final Map<UUID, Haunt> HAUNTS = new HashMap<>();

    private static final class Haunt {
        float attention;                         // grows when the player talks
        long lastSpawnTime = -1_000_000_000L;
        int secondsUntilScare = 30;
        int torchCooldown;
        int tick;
        final List<Delayed> delayed = new ArrayList<>();
    }

    private static final class Delayed {
        int ticks;
        final Runnable action;

        Delayed(int ticks, Runnable action) {
            this.ticks = ticks;
            this.action = action;
        }
    }

    // ------------------------------------------------------------------------------------------
    //  events
    // ------------------------------------------------------------------------------------------

    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.player instanceof ServerPlayer player)) {
            return;
        }
        if (player.isSpectator() || !player.isAlive()) {
            return;
        }
        Haunt haunt = HAUNTS.computeIfAbsent(player.getUUID(), id -> new Haunt());
        if (!haunt.delayed.isEmpty()) {
            runDelayed(haunt);
        }
        if (++haunt.tick % 20 == 0) {
            secondTick(player, haunt);
        }
    }

    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        BoxPlacer.onLogin(event);
    }

    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        HAUNTS.remove(event.getEntity().getUUID());
    }

    /** Called by {@link VoiceBrain} whenever the player says something. */
    public static void onPlayerSpoke(ServerPlayer player, String text, float loudness) {
        Haunt haunt = HAUNTS.computeIfAbsent(player.getUUID(), id -> new Haunt());
        haunt.attention += 4f + loudness * 14f + (text.isEmpty() ? 0f : 6f);
    }

    // ------------------------------------------------------------------------------------------
    //  once per second
    // ------------------------------------------------------------------------------------------

    private static void secondTick(ServerPlayer player, Haunt haunt) {
        ServerLevel level = player.serverLevel();
        RandomSource r = player.getRandom();

        haunt.attention = Math.max(0f, haunt.attention - 1f);
        if (haunt.torchCooldown > 0) {
            haunt.torchCooldown--;
        }

        List<VoiceHunterEntity> hunters = level.getEntitiesOfClass(VoiceHunterEntity.class,
                player.getBoundingBox().inflate(128.0), VoiceHunterEntity::isAlive);

        // ---- appearing -------------------------------------------------------------------
        if (CommonConfig.AUTO_SPAWN.get() && level.getDifficulty() != Difficulty.PEACEFUL
                && hunters.size() < CommonConfig.MAX_HUNTERS_PER_PLAYER.get()) {
            long now = level.getGameTime();
            boolean cooldownOver = now - haunt.lastSpawnTime >= CommonConfig.SPAWN_COOLDOWN_SECONDS.get() * 20L;
            boolean called = haunt.attention >= CommonConfig.ATTENTION_THRESHOLD.get();
            boolean dark = level.getMaxLocalRawBrightness(player.blockPosition()) <= 4;
            boolean passive = dark && r.nextDouble() < CommonConfig.PASSIVE_SPAWN_PER_MINUTE.get() / 60.0;
            if (cooldownOver && (called || passive) && spawnFor(player) != null) {
                haunt.lastSpawnTime = now;
                haunt.attention = 0f;
            }
        }

        // ---- presence --------------------------------------------------------------------
        VoiceHunterEntity nearest = nearestVisible(hunters, player);
        if (nearest != null) {
            double d = nearest.distanceTo(player);
            HunterState s = nearest.getHunterState();
            boolean menacing = s == HunterState.STALKING || s == HunterState.HUNTING
                    || s == HunterState.WATCHING || s == HunterState.COMING;
            if (menacing) {
                if (CommonConfig.DARKNESS_PULSES.get() && d < 24 && r.nextFloat() < 0.15f) {
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false, false));
                }
                if (CommonConfig.SNUFF_TORCHES.get() && d < 12 && haunt.torchCooldown <= 0
                        && r.nextFloat() < 0.5f && snuffTorch(level, player)) {
                    haunt.torchCooldown = 8;
                }
            }
        }

        // ---- random scares ---------------------------------------------------------------
        if (CommonConfig.AMBIENT_SCARES.get() && --haunt.secondsUntilScare <= 0) {
            ambientScare(level, player, haunt, hunters);
            int min = CommonConfig.SCARE_MIN_SECONDS.get();
            int max = Math.max(min + 1, CommonConfig.SCARE_MAX_SECONDS.get());
            int wait = min + r.nextInt(max - min + 1);
            if (nearest != null) {
                wait = (int) (wait * 0.6);
            }
            haunt.secondsUntilScare = Math.max(5, wait);
        }
    }

    @Nullable
    private static VoiceHunterEntity nearestVisible(List<VoiceHunterEntity> hunters, ServerPlayer player) {
        VoiceHunterEntity best = null;
        for (VoiceHunterEntity h : hunters) {
            if (h.isVanished()) {
                continue;
            }
            if (best == null || h.distanceToSqr(player) < best.distanceToSqr(player)) {
                best = h;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------------------------------
    //  spawning
    // ------------------------------------------------------------------------------------------

    @Nullable
    public static VoiceHunterEntity spawnFor(ServerPlayer player) {
        return spawnFor(player, CommonConfig.SPAWN_MIN_DISTANCE.get(), CommonConfig.SPAWN_MAX_DISTANCE.get());
    }

    /** Creates a monster that starts out watching {@code player} from {@code min..max} blocks away. */
    @Nullable
    public static VoiceHunterEntity spawnFor(ServerPlayer player, int min, int max) {
        ServerLevel level = player.serverLevel();
        RandomSource r = player.getRandom();
        BlockPos spot = SpawnHelper.findSpot(level, player.position(), min, Math.max(min + 2, max), r);
        if (spot == null) {
            return null;
        }
        VoiceHunterEntity hunter = ModEntities.VOICE_HUNTER.get().create(level);
        if (hunter == null) {
            return null;
        }
        double dx = player.getX() - (spot.getX() + 0.5);
        double dz = player.getZ() - (spot.getZ() + 0.5);
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        hunter.moveTo(spot.getX() + 0.5, spot.getY(), spot.getZ() + 0.5, yaw, 0.0f);
        hunter.bindTo(player);
        hunter.setState(HunterState.WATCHING, 400 + r.nextInt(400));
        level.addFreshEntity(hunter);
        Scares.playTo(player, ModSounds.DRONE.get(), SoundSource.AMBIENT,
                player.getX(), player.getY(), player.getZ(), 0.8f, 1.0f);
        return hunter;
    }

    /** The monster comes out of an opened Hunter Box at {@code pos}. Its own behaviour is unchanged. */
    @Nullable
    public static VoiceHunterEntity releaseAt(ServerLevel level, ServerPlayer player, BlockPos pos) {
        VoiceHunterEntity hunter = ModEntities.VOICE_HUNTER.get().create(level);
        if (hunter == null) {
            return null;
        }
        double dx = player.getX() - (pos.getX() + 0.5);
        double dz = player.getZ() - (pos.getZ() + 0.5);
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
        hunter.moveTo(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, yaw, 0.0f);
        hunter.bindTo(player);
        hunter.setState(HunterState.IDLE, -1);
        level.addFreshEntity(hunter);
        Scares.playTo(player, ModSounds.STING.get(), SoundSource.HOSTILE,
                player.getX(), player.getY(), player.getZ(), 1.0f, 1.0f);
        return hunter;
    }

    // ------------------------------------------------------------------------------------------
    //  scares only the player hears
    // ------------------------------------------------------------------------------------------

    private static void ambientScare(ServerLevel level, ServerPlayer player, Haunt haunt,
                                     List<VoiceHunterEntity> hunters) {
        RandomSource r = player.getRandom();
        int pick = r.nextInt(100);
        if (pick < 22) {
            Scares.playBehind(player, ModSounds.HUNTER_WHISPER.get(), 2.2, 0.9f, 0.8f + r.nextFloat() * 0.4f);
        } else if (pick < 40) {
            footsteps(player, haunt);
        } else if (pick < 52) {
            heartbeat(player, haunt);
        } else if (pick < 62) {
            Scares.playTo(player, ModSounds.DRONE.get(), SoundSource.AMBIENT,
                    player.getX(), player.getY(), player.getZ(), 0.7f, 0.9f + r.nextFloat() * 0.2f);
        } else if (pick < 72) {
            Scares.playBehind(player, ModSounds.HUNTER_BREATH.get(), 1.2, 0.9f, 0.7f);
        } else if (pick < 80) {
            Scares.playAround(player, r.nextBoolean() ? SoundEvents.WOODEN_DOOR_OPEN : SoundEvents.WOODEN_DOOR_CLOSE,
                    10 + r.nextInt(14), 0.8f, 0.9f);
        } else if (pick < 85) {
            knocking(player, haunt);
        } else if (pick < 90) {
            Scares.playAround(player, ModSounds.STING.get(), 22, 0.6f, 0.9f + r.nextFloat() * 0.3f);
        } else if (pick < 94) {
            distantFlash(level, player);
        } else if (!hunters.isEmpty()) {
            hunters.get(0).triggerApparition();
        } else {
            Scares.playBehind(player, ModSounds.HUNTER_WHISPER.get(), 1.5, 1.0f, 0.7f);
        }
    }

    private static void footsteps(ServerPlayer player, Haunt haunt) {
        // somebody walking up behind you, getting closer with every step
        int steps = 5 + player.getRandom().nextInt(3);
        for (int i = 0; i < steps; i++) {
            final double dist = 9.0 - i * (6.0 / steps);
            haunt.delayed.add(new Delayed(i * 11, () ->
                    Scares.playBehind(player, ModSounds.HUNTER_STEP.get(), dist, 0.8f, 0.85f)));
        }
    }

    private static void heartbeat(ServerPlayer player, Haunt haunt) {
        for (int i = 0; i < 4; i++) {
            haunt.delayed.add(new Delayed(i * 18, () -> Scares.playTo(player, ModSounds.HEARTBEAT.get(),
                    SoundSource.AMBIENT, player.getX(), player.getY(), player.getZ(), 0.9f, 1.0f)));
        }
    }

    private static void knocking(ServerPlayer player, Haunt haunt) {
        double dist = 5 + player.getRandom().nextInt(6);
        for (int i = 0; i < 3; i++) {
            haunt.delayed.add(new Delayed(i * 14, () -> Scares.playBehind(player,
                    SoundEvents.ZOMBIE_ATTACK_WOODEN_DOOR, dist, 0.9f, 0.9f)));
        }
    }

    /** A flash of lightning on the horizon with no storm. Visual only: no fire, no damage. */
    private static void distantFlash(ServerLevel level, ServerPlayer player) {
        if (level.dimension() != Level.OVERWORLD) {
            return;
        }
        RandomSource r = player.getRandom();
        double angle = r.nextDouble() * Math.PI * 2.0;
        double d = 70 + r.nextInt(40);
        BlockPos column = BlockPos.containing(player.getX() + Math.cos(angle) * d, 0, player.getZ() + Math.sin(angle) * d);
        if (!level.hasChunkAt(column)) {
            return;
        }
        BlockPos top = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, column);
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) {
            bolt.moveTo(Vec3.atBottomCenterOf(top));
            bolt.setVisualOnly(true);
            level.addFreshEntity(bolt);
        }
    }

    /** The monster puts out a torch or lantern near the player (it drops as an item, nothing is lost). */
    private static boolean snuffTorch(ServerLevel level, ServerPlayer player) {
        BlockPos c = player.blockPosition();
        List<BlockPos> found = new ArrayList<>();
        for (BlockPos pos : BlockPos.betweenClosed(c.offset(-7, -3, -7), c.offset(7, 4, 7))) {
            BlockState s = level.getBlockState(pos);
            if (s.is(Blocks.TORCH) || s.is(Blocks.WALL_TORCH) || s.is(Blocks.SOUL_TORCH)
                    || s.is(Blocks.SOUL_WALL_TORCH) || s.is(Blocks.LANTERN) || s.is(Blocks.SOUL_LANTERN)) {
                found.add(pos.immutable());
            }
        }
        if (found.isEmpty()) {
            return false;
        }
        BlockPos target = found.get(player.getRandom().nextInt(found.size()));
        level.destroyBlock(target, true);
        level.playSound(null, target, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.7f, 1.0f);
        return true;
    }

    private static void runDelayed(Haunt haunt) {
        List<Runnable> due = null;
        for (Iterator<Delayed> it = haunt.delayed.iterator(); it.hasNext(); ) {
            Delayed d = it.next();
            if (--d.ticks <= 0) {
                if (due == null) {
                    due = new ArrayList<>();
                }
                due.add(d.action);
                it.remove();
            }
        }
        if (due != null) {
            due.forEach(Runnable::run);
        }
    }

    private HauntDirector() {
    }
}
