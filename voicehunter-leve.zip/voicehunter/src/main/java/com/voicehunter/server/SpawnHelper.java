package com.voicehunter.server;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/** Helpers to find places where the (tall) monster can stand, in caves as well as on the surface. */
public final class SpawnHelper {

    /** Scans a column from top to bottom and returns the first place with a solid floor and 3 free blocks. */
    @Nullable
    public static BlockPos findStandable(ServerLevel level, BlockPos column, int up, int down) {
        for (int dy = up; dy >= -down; dy--) {
            BlockPos feet = column.offset(0, dy, 0);
            if (!level.hasChunkAt(feet) || feet.getY() < level.getMinBuildHeight() + 1
                    || feet.getY() > level.getMaxBuildHeight() - 4) {
                continue;
            }
            BlockPos floorPos = feet.below();
            BlockState floor = level.getBlockState(floorPos);
            if (!floor.isFaceSturdy(level, floorPos, Direction.UP) || !level.getFluidState(floorPos).isEmpty()) {
                continue;
            }
            if (isFree(level, feet) && isFree(level, feet.above()) && isFree(level, feet.above(2))) {
                return feet;
            }
        }
        return null;
    }

    private static boolean isFree(ServerLevel level, BlockPos pos) {
        return level.getBlockState(pos).getCollisionShape(level, pos).isEmpty()
                && level.getFluidState(pos).isEmpty();
    }

    public static boolean isDark(ServerLevel level, BlockPos pos) {
        return level.getMaxLocalRawBrightness(pos) <= 7;
    }

    /** A random standable spot on a ring around {@code center}; dark places are preferred. */
    @Nullable
    public static BlockPos findSpot(ServerLevel level, Vec3 center, int min, int max, RandomSource r) {
        if (max <= min) {
            max = min + 1;
        }
        BlockPos fallback = null;
        for (int i = 0; i < 18; i++) {
            double angle = r.nextDouble() * Math.PI * 2.0;
            double d = min + r.nextInt(max - min + 1);
            BlockPos column = BlockPos.containing(center.x + Math.cos(angle) * d, center.y, center.z + Math.sin(angle) * d);
            BlockPos spot = findStandable(level, column, 10, 14);
            if (spot == null) {
                continue;
            }
            if (isDark(level, spot)) {
                return spot;
            }
            if (fallback == null) {
                fallback = spot;
            }
        }
        return fallback;
    }

    /** A spot a few blocks behind the player's back (relative to where they are looking). */
    @Nullable
    public static BlockPos behind(ServerLevel level, Player player, double dist, RandomSource r) {
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        if (flat.lengthSqr() < 1.0E-4) {
            flat = new Vec3(0, 0, 1);
        }
        flat = flat.normalize();
        for (int i = 0; i < 8; i++) {
            double jitter = (r.nextDouble() - 0.5) * 1.2;
            double d = dist + i * 0.4;
            double x = player.getX() - flat.x * d + (-flat.z) * jitter * d * 0.4;
            double z = player.getZ() - flat.z * d + flat.x * jitter * d * 0.4;
            BlockPos spot = findStandable(level, BlockPos.containing(x, player.getY(), z), 3, 5);
            if (spot != null) {
                return spot;
            }
        }
        return null;
    }

    private SpawnHelper() {
    }
}
