package com.voicehunter.config;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Gameplay settings (config/voicehunter-common.toml). Used on the server / integrated server. */
public final class CommonConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.BooleanValue BOX_AT_SPAWN;
    public static final ModConfigSpec.BooleanValue AUTO_SPAWN;
    public static final ModConfigSpec.DoubleValue ATTENTION_THRESHOLD;
    public static final ModConfigSpec.DoubleValue PASSIVE_SPAWN_PER_MINUTE;
    public static final ModConfigSpec.IntValue MAX_HUNTERS_PER_PLAYER;
    public static final ModConfigSpec.IntValue SPAWN_COOLDOWN_SECONDS;
    public static final ModConfigSpec.IntValue SPAWN_MIN_DISTANCE;
    public static final ModConfigSpec.IntValue SPAWN_MAX_DISTANCE;

    public static final ModConfigSpec.BooleanValue AMBIENT_SCARES;
    public static final ModConfigSpec.IntValue SCARE_MIN_SECONDS;
    public static final ModConfigSpec.IntValue SCARE_MAX_SECONDS;
    public static final ModConfigSpec.BooleanValue SNUFF_TORCHES;
    public static final ModConfigSpec.BooleanValue DARKNESS_PULSES;

    public static final ModConfigSpec.IntValue COMMAND_RANGE;
    public static final ModConfigSpec.DoubleValue DISOBEDIENCE_SCALE;
    public static final ModConfigSpec.BooleanValue ALLOW_AGGRESSION;
    public static final ModConfigSpec.DoubleValue DAMAGE_SCALE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("When and how the Voice Hunter shows up on its own").push("spawning");
        BOX_AT_SPAWN = b.comment("The first time a player joins a world, a cardboard Hunter Box is placed on the ground nearby.",
                        "The monster is inside: it only comes out when the player opens the box (right click).")
                .define("boxAtFirstJoin", true);
        AUTO_SPAWN = b.comment("Let the monster ALSO appear by itself (attracted by your voice and by the dark),",
                        "without a box. Default false: the box is the way in.")
                .define("autoSpawn", false);
        ATTENTION_THRESHOLD = b.comment("Every time a player speaks, 'attention' builds up. When it reaches this value the monster appears.")
                .defineInRange("attentionThreshold", 100.0, 10.0, 1000.0);
        PASSIVE_SPAWN_PER_MINUTE = b.comment("Chance per minute (0..1) that the monster appears in the dark even if you stay silent.")
                .defineInRange("passiveSpawnChancePerMinute", 0.05, 0.0, 1.0);
        MAX_HUNTERS_PER_PLAYER = b.comment("Maximum monsters near one player.")
                .defineInRange("maxHuntersPerPlayer", 1, 1, 5);
        SPAWN_COOLDOWN_SECONDS = b.comment("Minimum seconds between two automatic appearances for the same player.")
                .defineInRange("spawnCooldownSeconds", 240, 10, 36000);
        SPAWN_MIN_DISTANCE = b.defineInRange("spawnMinDistance", 28, 10, 100);
        SPAWN_MAX_DISTANCE = b.defineInRange("spawnMaxDistance", 44, 12, 128);
        b.pop();

        b.comment("Atmosphere: random scares, lights and darkness").push("atmosphere");
        AMBIENT_SCARES = b.comment("Random whispers, footsteps, heartbeats and drones around the player.")
                .define("ambientScares", true);
        SCARE_MIN_SECONDS = b.defineInRange("scareMinSeconds", 40, 5, 3600);
        SCARE_MAX_SECONDS = b.defineInRange("scareMaxSeconds", 140, 10, 7200);
        SNUFF_TORCHES = b.comment("The monster knocks torches/lanterns off near you when it is close (they drop as items).")
                .define("snuffTorches", true);
        DARKNESS_PULSES = b.comment("Pulses of the Darkness effect when the monster is menacing and close.")
                .define("darknessPulses", true);
        b.pop();

        b.comment("Monster personality / voice interaction").push("monster");
        COMMAND_RANGE = b.comment("Distance (blocks) from which the monster can understand your voice commands.")
                .defineInRange("commandRange", 96, 8, 256);
        DISOBEDIENCE_SCALE = b.comment("0 = always obeys, 1 = default personality, 2 = very rebellious / unpredictable.")
                .defineInRange("disobedienceScale", 1.0, 0.0, 2.0);
        ALLOW_AGGRESSION = b.comment("Allow the monster to attack. If false it only stalks, watches and scares.")
                .define("allowAggression", true);
        DAMAGE_SCALE = b.comment("Multiplier for the monster's melee damage (base 6).")
                .defineInRange("damageScale", 1.0, 0.0, 10.0);
        b.pop();

        SPEC = b.build();
    }

    private CommonConfig() {
    }
}
