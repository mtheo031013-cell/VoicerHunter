package com.voicehunter.config;

import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.List;

/** Client settings (config/voicehunter-client.toml): microphone, speech model, HUD, effects. */
public final class ClientConfig {
    public static final ModConfigSpec SPEC;

    public static final ModConfigSpec.ConfigValue<String> MICROPHONE;
    public static final ModConfigSpec.BooleanValue AUTO_START;
    public static final ModConfigSpec.DoubleValue INPUT_GAIN;
    public static final ModConfigSpec.DoubleValue VOICE_THRESHOLD;
    public static final ModConfigSpec.BooleanValue SEND_NOISE;

    public static final ModConfigSpec.ConfigValue<String> LANGUAGE;
    public static final ModConfigSpec.BooleanValue AUTO_DOWNLOAD;
    public static final ModConfigSpec.ConfigValue<String> CUSTOM_MODEL_DIR;
    public static final ModConfigSpec.ConfigValue<String> CUSTOM_MODEL_URL;

    public static final ModConfigSpec.BooleanValue SHOW_HUD;
    public static final ModConfigSpec.DoubleValue HUD_SCALE;
    public static final ModConfigSpec.BooleanValue ATMOSPHERE;

    static {
        ModConfigSpec.Builder b = new ModConfigSpec.Builder();

        b.comment("Microphone").push("microphone");
        MICROPHONE = b.comment("Part of the input device name to use (empty = system default). Use /voicemic list in game.")
                .define("device", "");
        AUTO_START = b.comment("Start listening automatically when you join a world. Default false: you decide with the key.")
                .define("autoStart", false);
        INPUT_GAIN = b.comment("Software amplification of the microphone signal.")
                .defineInRange("inputGain", 1.0, 0.2, 12.0);
        VOICE_THRESHOLD = b.comment("Volume (0..1) above which the monster notices that you are making noise, even without words.")
                .defineInRange("voiceThreshold", 0.02, 0.002, 0.5);
        SEND_NOISE = b.comment("Tell the monster when you are speaking before the words are recognised.")
                .define("sendNoiseEvents", true);
        b.pop();

        b.comment("Speech recognition (Vosk, offline). Only text is sent to the game, never audio.").push("recognition");
        LANGUAGE = b.comment("Language of the speech model: pt (Portuguese) or en (English).")
                .defineInList("language", "pt", List.of("pt", "en"));
        AUTO_DOWNLOAD = b.comment("Download the speech model (about 31-40 MB) from alphacephei.com on first use.")
                .define("autoDownloadModel", true);
        CUSTOM_MODEL_DIR = b.comment("Advanced: folder name inside <game>/voicehunter/models to use instead of the default model.")
                .define("customModelDir", "");
        CUSTOM_MODEL_URL = b.comment("Advanced: zip URL to download when customModelDir is set and missing.")
                .define("customModelUrl", "");
        b.pop();

        b.comment("Interface and effects").push("interface");
        SHOW_HUD = b.define("showHud", true);
        HUD_SCALE = b.defineInRange("hudScale", 1.0, 0.5, 2.0);
        ATMOSPHERE = b.comment("Fog, vignette, heartbeat and camera shake when the monster is near.")
                .define("atmosphereEffects", true);
        b.pop();

        SPEC = b.build();
    }

    private ClientConfig() {
    }
}
