package com.voicehunter.network;

import com.voicehunter.VoiceHunterMod;
import com.voicehunter.server.VoiceBrain;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/** Registers the two packets of the mod (Forge SimpleChannel). */
public final class ModNetwork {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VoiceHunterMod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    /** Called once from the common setup. */
    public static void register() {
        // client -> server: what the player said
        CHANNEL.registerMessage(0, VoiceHeardPayload.class, VoiceHeardPayload::write, VoiceHeardPayload::new,
                ModNetwork::handleVoice);

        // server -> client: how the monster reacted
        CHANNEL.registerMessage(1, HunterFeedbackPayload.class, HunterFeedbackPayload::write, HunterFeedbackPayload::new,
                ModNetwork::handleFeedback);
    }

    public static void sendToServer(VoiceHeardPayload payload) {
        CHANNEL.sendToServer(payload);
    }

    public static void sendToPlayer(ServerPlayer player, HunterFeedbackPayload payload) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), payload);
    }

    private static void handleVoice(VoiceHeardPayload payload, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player != null) {
                VoiceBrain.onVoice(player, payload.text(), payload.loudness());
            }
        });
        c.setPacketHandled(true);
    }

    private static void handleFeedback(HunterFeedbackPayload payload, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        // only runs on the client, so the client-only class is never loaded on a dedicated server
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.voicehunter.client.ClientHooks.onFeedback(payload)));
        c.setPacketHandled(true);
    }

    private ModNetwork() {
    }
}
