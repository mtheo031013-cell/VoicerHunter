package com.voicehunter.network;

import net.minecraft.network.FriendlyByteBuf;

/**
 * Server -> client. Tells the speaker how the monster reacted (drives the "did it understand?" HUD).
 *
 * @param reaction   {@link com.voicehunter.entity.Reaction} ordinal
 * @param intent     {@link com.voicehunter.voice.Intent} ordinal the monster THINKS it heard, or -1
 * @param state      {@link com.voicehunter.entity.HunterState} ordinal of the monster now, or -1
 * @param distance   blocks between player and monster, or -1
 */
public record HunterFeedbackPayload(int reaction, int intent, int state, float distance) {
    public HunterFeedbackPayload(FriendlyByteBuf buf) {
        this(buf.readVarInt(), buf.readVarInt() - 1, buf.readVarInt() - 1, buf.readFloat());
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeVarInt(reaction);
        buf.writeVarInt(intent + 1);
        buf.writeVarInt(state + 1);
        buf.writeFloat(distance);
    }
}
