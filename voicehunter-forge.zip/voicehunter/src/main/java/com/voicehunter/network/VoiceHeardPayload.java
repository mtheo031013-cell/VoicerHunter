package com.voicehunter.network;

import net.minecraft.network.FriendlyByteBuf;

/**
 * Client -> server. The client recognised speech locally and tells the server WHAT was said
 * (text only, never audio). {@code text} is empty when only a voice/noise was detected.
 *
 * @param loudness 0..1 (1 = shouting)
 */
public record VoiceHeardPayload(String text, float loudness) {
    public VoiceHeardPayload(FriendlyByteBuf buf) {
        this(buf.readUtf(256), buf.readFloat());
    }

    public void write(FriendlyByteBuf buf) {
        buf.writeUtf(text, 256);
        buf.writeFloat(loudness);
    }
}
