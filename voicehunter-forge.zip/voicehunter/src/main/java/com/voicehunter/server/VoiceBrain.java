package com.voicehunter.server;

import com.voicehunter.config.CommonConfig;
import com.voicehunter.entity.HearResult;
import com.voicehunter.entity.Reaction;
import com.voicehunter.entity.VoiceHunterEntity;
import com.voicehunter.network.HunterFeedbackPayload;
import com.voicehunter.voice.IntentParser;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import com.voicehunter.network.ModNetwork;

import java.util.List;

/**
 * Server entry point for everything a player says. The client sends only TEXT (never audio);
 * here the text is parsed into an intent and handed to the monsters that are close enough to hear.
 */
public final class VoiceBrain {

    public static void onVoice(ServerPlayer player, String rawText, float rawLoudness) {
        String text = rawText == null ? "" : rawText.trim();
        if (text.length() > 200) {
            text = text.substring(0, 200); // never trust the client
        }
        float loudness = Float.isNaN(rawLoudness) ? 0f : Mth.clamp(rawLoudness, 0f, 1f);
        if (player.isSpectator()) {
            return;
        }

        ServerLevel level = player.serverLevel();
        double range = CommonConfig.COMMAND_RANGE.get();
        List<VoiceHunterEntity> hunters = level.getEntitiesOfClass(VoiceHunterEntity.class,
                player.getBoundingBox().inflate(range), VoiceHunterEntity::isAlive);

        // the voice always draws attention, even if there is no monster yet
        HauntDirector.onPlayerSpoke(player, text, loudness);

        if (hunters.isEmpty()) {
            sendFeedback(player, new HearResult(Reaction.NO_MONSTER, null), null);
            return;
        }

        VoiceHunterEntity nearest = null;
        for (VoiceHunterEntity h : hunters) {
            if (nearest == null || h.distanceToSqr(player) < nearest.distanceToSqr(player)) {
                nearest = h;
            }
        }

        IntentParser.Match match = text.isEmpty() ? null : IntentParser.parse(text);
        HearResult result = nearest.hear(player, match, text, loudness);

        // other monsters in earshot get the sound of the voice, but only the closest one answers
        for (VoiceHunterEntity h : hunters) {
            if (h != nearest) {
                h.hear(player, null, "", loudness);
            }
        }
        sendFeedback(player, result, nearest);
    }

    private static void sendFeedback(ServerPlayer player, HearResult result, VoiceHunterEntity hunter) {
        int intent = result.understood() == null ? -1 : result.understood().ordinal();
        int state = hunter == null ? -1 : hunter.getHunterState().ordinal();
        float distance = hunter == null ? -1f : hunter.distanceTo(player);
        ModNetwork.sendToPlayer(player,
                new HunterFeedbackPayload(result.reaction().ordinal(), intent, state, distance));
    }

    private VoiceBrain() {
    }
}
