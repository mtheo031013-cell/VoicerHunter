package com.voicehunter.server;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.voicehunter.entity.VoiceHunterEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.RegisterCommandsEvent;

import java.util.List;
import java.util.Locale;

/**
 * Operator commands (permission level 2):
 * <pre>
 *   /voicehunter summon   spawn a monster 18-26 blocks from you
 *   /voicehunter box      place a Hunter Box in front of you
 *   /voicehunter dismiss  remove every monster within 256 blocks
 *   /voicehunter status   state and mood of the monsters nearby
 *   /voicehunter calm     reset their mood
 * </pre>
 * There is deliberately NO command that injects fake speech: the monster only reacts to the real microphone.
 */
public final class ModCommands {

    public static void register(RegisterCommandsEvent event) {
        CommandDispatcher<CommandSourceStack> dispatcher = event.getDispatcher();
        dispatcher.register(Commands.literal("voicehunter")
                .requires(src -> src.hasPermission(2))
                .then(Commands.literal("summon").executes(ctx -> summon(ctx.getSource())))
                .then(Commands.literal("box").executes(ctx -> box(ctx.getSource())))
                .then(Commands.literal("dismiss").executes(ctx -> dismiss(ctx.getSource())))
                .then(Commands.literal("status").executes(ctx -> status(ctx.getSource())))
                .then(Commands.literal("calm").executes(ctx -> calm(ctx.getSource()))));
    }

    private static int summon(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer player = src.getPlayerOrException();
        VoiceHunterEntity hunter = HauntDirector.spawnFor(player, 18, 26);
        if (hunter == null) {
            src.sendFailure(Component.translatable("command.voicehunter.no_space"));
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("command.voicehunter.summoned"), true);
        return 1;
    }

    private static int box(CommandSourceStack src) throws CommandSyntaxException {
        if (BoxPlacer.placeInFront(src.getPlayerOrException()) == null) {
            src.sendFailure(Component.translatable("command.voicehunter.no_space"));
            return 0;
        }
        src.sendSuccess(() -> Component.translatable("command.voicehunter.box_placed"), true);
        return 1;
    }

    private static List<VoiceHunterEntity> nearby(CommandSourceStack src) {
        return src.getLevel().getEntitiesOfClass(VoiceHunterEntity.class,
                AABB.ofSize(src.getPosition(), 512, 512, 512), VoiceHunterEntity::isAlive);
    }

    private static int dismiss(CommandSourceStack src) {
        List<VoiceHunterEntity> list = nearby(src);
        list.forEach(VoiceHunterEntity::discard);
        src.sendSuccess(() -> Component.translatable("command.voicehunter.dismissed", list.size()), true);
        return list.size();
    }

    private static int status(CommandSourceStack src) {
        List<VoiceHunterEntity> list = nearby(src);
        if (list.isEmpty()) {
            src.sendSuccess(() -> Component.translatable("command.voicehunter.none"), false);
            return 0;
        }
        for (VoiceHunterEntity h : list) {
            String line = String.format(Locale.ROOT,
                    "%s | dist %.0f | aggression %.2f trust %.2f | obedience %.2f mischief %.2f curiosity %.2f%s",
                    h.getHunterState().key(), Math.sqrt(h.distanceToSqr(src.getPosition())),
                    h.personality.aggression, h.personality.trust,
                    h.personality.obedience, h.personality.mischief, h.personality.curiosity,
                    h.personality.fakeSleeper ? " | light sleeper" : "");
            src.sendSuccess(() -> Component.literal(line), false);
        }
        return list.size();
    }

    private static int calm(CommandSourceStack src) {
        List<VoiceHunterEntity> list = nearby(src);
        for (VoiceHunterEntity h : list) {
            h.personality.aggression = 0f;
            h.personality.trust = 0.3f;
        }
        src.sendSuccess(() -> Component.translatable("command.voicehunter.calmed", list.size()), true);
        return list.size();
    }

    private ModCommands() {
    }
}
