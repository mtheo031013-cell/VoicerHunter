package com.voicehunter.server;

import com.voicehunter.config.CommonConfig;
import com.voicehunter.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.player.PlayerEvent;

import javax.annotation.Nullable;

/** Puts the cardboard box on the ground in front of the player the first time they enter a world. */
public final class BoxPlacer {

    private static final String FLAG = "voicehunter_box_placed";

    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !CommonConfig.BOX_AT_SPAWN.get()) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        if (data.getBoolean(FLAG)) {
            return;
        }
        if (placeInFront(player) != null) {
            data.putBoolean(FLAG, true);
        }
    }

    /** Places a box 4-6 blocks in front of the player (where they look horizontally). */
    @Nullable
    public static BlockPos placeInFront(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        Vec3 look = player.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        flat = flat.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : flat.normalize();
        for (int dist = 5; dist <= 8; dist++) {
            for (int side = 0; side < 3; side++) {
                double off = (side == 0 ? 0 : side == 1 ? 1.5 : -1.5);
                double x = player.getX() + flat.x * dist - flat.z * off;
                double z = player.getZ() + flat.z * dist + flat.x * off;
                BlockPos spot = SpawnHelper.findStandable(level, BlockPos.containing(x, player.getY(), z), 4, 6);
                if (spot != null) {
                    level.setBlock(spot, ModBlocks.HUNTER_BOX.get().defaultBlockState(), 3);
                    return spot;
                }
            }
        }
        return null;
    }

    private BoxPlacer() {
    }
}
