package com.voicehunter.registry;

import com.voicehunter.VoiceHunterMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(Registries.ITEM, VoiceHunterMod.MODID);

    public static final RegistryObject<ForgeSpawnEggItem> VOICE_HUNTER_SPAWN_EGG =
            ITEMS.register("voice_hunter_spawn_egg", () ->
                    new ForgeSpawnEggItem(ModEntities.VOICE_HUNTER, 0x15151a, 0xb01818, new Item.Properties()));

    public static final RegistryObject<BlockItem> HUNTER_BOX =
            ITEMS.register("hunter_box", () -> new BlockItem(ModBlocks.HUNTER_BOX.get(), new Item.Properties()));

    private ModItems() {
    }
}
