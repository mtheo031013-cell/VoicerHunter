package com.voicehunter.registry;

import com.voicehunter.VoiceHunterMod;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, VoiceHunterMod.MODID);

    public static final RegistryObject<SoundEvent> HUNTER_BREATH = reg("hunter_breath");
    public static final RegistryObject<SoundEvent> HUNTER_STEP = reg("hunter_step");
    public static final RegistryObject<SoundEvent> HUNTER_GROWL = reg("hunter_growl");
    public static final RegistryObject<SoundEvent> HUNTER_SCREECH = reg("hunter_screech");
    public static final RegistryObject<SoundEvent> HUNTER_VANISH = reg("hunter_vanish");
    public static final RegistryObject<SoundEvent> HUNTER_WHISPER = reg("hunter_whisper");
    public static final RegistryObject<SoundEvent> HUNTER_HURT = reg("hunter_hurt");
    public static final RegistryObject<SoundEvent> HUNTER_DEATH = reg("hunter_death");
    public static final RegistryObject<SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final RegistryObject<SoundEvent> DRONE = reg("drone");
    public static final RegistryObject<SoundEvent> STING = reg("sting");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(VoiceHunterMod.MODID, name)));
    }

    private ModSounds() {
    }
}
