package com.voicehunter;

import com.mojang.logging.LogUtils;
import com.voicehunter.client.ClientInit;
import com.voicehunter.config.ClientConfig;
import com.voicehunter.config.CommonConfig;
import com.voicehunter.entity.VoiceHunterEntity;
import com.voicehunter.network.ModNetwork;
import com.voicehunter.registry.ModBlocks;
import com.voicehunter.registry.ModEntities;
import com.voicehunter.registry.ModItems;
import com.voicehunter.registry.ModSounds;
import com.voicehunter.server.HauntDirector;
import com.voicehunter.server.ModCommands;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import org.slf4j.Logger;

@Mod(VoiceHunterMod.MODID)
public class VoiceHunterMod {
    public static final String MODID = "voicehunter";
    public static final Logger LOGGER = LogUtils.getLogger();

    public VoiceHunterMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, CommonConfig.SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);

        ModSounds.SOUNDS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);

        modBus.addListener(this::onAttributes);
        modBus.addListener(this::onCreativeTab);
        modBus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(ModNetwork::register));

        // server-side (also runs in single player)
        MinecraftForge.EVENT_BUS.addListener(HauntDirector::onPlayerTick);
        MinecraftForge.EVENT_BUS.addListener(HauntDirector::onPlayerLogout);
        MinecraftForge.EVENT_BUS.addListener(HauntDirector::onPlayerLogin);
        MinecraftForge.EVENT_BUS.addListener(ModCommands::register);

        // client-only code is isolated in ClientInit so a dedicated server never loads it
        if (FMLEnvironment.dist == Dist.CLIENT) {
            ClientInit.init(modBus);
        }
    }

    private void onAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.VOICE_HUNTER.get(), VoiceHunterEntity.createAttributes().build());
    }

    private void onCreativeTab(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModItems.VOICE_HUNTER_SPAWN_EGG.get());
        }
        if (event.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) {
            event.accept(ModItems.HUNTER_BOX.get());
        }
    }
}
