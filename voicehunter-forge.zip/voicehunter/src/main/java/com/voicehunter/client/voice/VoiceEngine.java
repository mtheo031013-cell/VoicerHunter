package com.voicehunter.client.voice;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.client.ClientState;
import com.voicehunter.config.ClientConfig;
import com.voicehunter.network.VoiceHeardPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import com.voicehunter.network.ModNetwork;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.TargetDataLine;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Real-time microphone capture + speech recognition, on its own thread so the game never stalls.
 * <p>
 * Flow: microphone (Java Sound) -> Vosk recogniser -> text -> {@link VoiceHeardPayload} to the server.
 * Only text leaves this class; the audio is never stored or sent anywhere.
 * <p>
 * This class does not touch the Vosk classes (see {@link VoskBackend}), so the game survives
 * a machine where the native library cannot be loaded: the HUD just shows the error.
 */
public final class VoiceEngine {

    public static final VoiceEngine INSTANCE = new VoiceEngine();

    public enum Status {
        OFF, PREPARING, LISTENING, ERROR
    }

    private static final float TARGET_RATE = 16000f;

    private volatile Status status = Status.OFF;
    private volatile Component detail = Component.empty();
    private volatile int generation;

    private VoiceEngine() {
    }

    // ------------------------------------------------------------------------------------------
    //  public API (main thread)
    // ------------------------------------------------------------------------------------------

    public Status getStatus() {
        return status;
    }

    public Component getDetail() {
        return detail;
    }

    public boolean isActive() {
        return status == Status.LISTENING || status == Status.PREPARING;
    }

    public void toggle() {
        if (isActive()) {
            stop();
        } else {
            start();
        }
    }

    public synchronized void start() {
        if (isActive()) {
            return;
        }
        final int gen = ++generation;
        status = Status.PREPARING;
        detail = Component.translatable("gui.voicehunter.mic.preparing");
        Thread thread = new Thread(() -> run(gen), "VoiceHunter-Recognizer");
        thread.setDaemon(true);
        thread.start();
    }

    public synchronized void stop() {
        generation++; // tells a running thread to finish
        status = Status.OFF;
        detail = Component.empty();
        ClientState.micLevel = 0f;
        ClientState.partial = "";
    }

    /** Names of the input devices that can record speech. Used by {@code /voicemic list}. */
    public static List<String> listMicrophones() {
        List<String> names = new ArrayList<>();
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, new AudioFormat(TARGET_RATE, 16, 1, true, false));
        DataLine.Info info48 = new DataLine.Info(TargetDataLine.class, new AudioFormat(48000f, 16, 1, true, false));
        DataLine.Info info44 = new DataLine.Info(TargetDataLine.class, new AudioFormat(44100f, 16, 1, true, false));
        for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
            Mixer mixer = AudioSystem.getMixer(mi);
            if (mixer.isLineSupported(info) || mixer.isLineSupported(info48) || mixer.isLineSupported(info44)) {
                names.add(mi.getName());
            }
        }
        return names;
    }

    // ------------------------------------------------------------------------------------------
    //  worker thread
    // ------------------------------------------------------------------------------------------

    private void run(int gen) {
        TargetDataLine line = null;
        SpeechRecognizer recognizer = null;
        try {
            var modelDir = ModelManager.ensureModel(percent -> {
                if (gen == generation) {
                    detail = Component.translatable("gui.voicehunter.mic.downloading", percent);
                }
            });
            if (gen != generation) {
                return;
            }
            detail = Component.translatable("gui.voicehunter.mic.loading_model");
            recognizer = VoskBackend.create(modelDir, TARGET_RATE);
            if (gen != generation) {
                return;
            }

            float captureRate = TARGET_RATE;
            line = openMicrophone(TARGET_RATE);
            if (line == null) {
                captureRate = 48000f;
                line = openMicrophone(captureRate);
            }
            if (line == null) {
                captureRate = 44100f;
                line = openMicrophone(captureRate);
            }
            if (line == null) {
                throw new LineUnavailableException("no input device available");
            }

            if (gen == generation) {
                status = Status.LISTENING;
                detail = Component.translatable("gui.voicehunter.mic.listening");
                VoiceHunterMod.LOGGER.info("Voice recognition started (capture rate {} Hz)", captureRate);
            }
            listen(gen, line, recognizer, captureRate);

        } catch (ModelManager.ModelException e) {
            fail(gen, e.component(), e);
        } catch (LineUnavailableException | SecurityException e) {
            fail(gen, Component.translatable("gui.voicehunter.error.mic", String.valueOf(e.getMessage())), e);
        } catch (UnsatisfiedLinkError | NoClassDefFoundError e) {
            fail(gen, Component.translatable("gui.voicehunter.error.vosk", String.valueOf(e.getMessage())), e);
        } catch (Throwable t) {
            fail(gen, Component.translatable("gui.voicehunter.error.generic", String.valueOf(t)), t);
        } finally {
            if (line != null) {
                try {
                    line.stop();
                    line.close();
                } catch (RuntimeException ignored) {
                    // closing a dead line, nothing to do
                }
            }
            if (recognizer != null) {
                try {
                    recognizer.close();
                } catch (RuntimeException ignored) {
                    // nothing to do
                }
            }
            synchronized (this) {
                if (gen == generation && status != Status.ERROR) {
                    status = Status.OFF;
                }
            }
            ClientState.micLevel = 0f;
        }
    }

    private void fail(int gen, Component message, Throwable cause) {
        VoiceHunterMod.LOGGER.error("Voice recognition stopped: {}", message.getString(), cause);
        synchronized (this) {
            if (gen == generation) {
                status = Status.ERROR;
                detail = message;
            }
        }
    }

    /** The recognition loop: read audio, measure volume, recognise, send what was said. */
    private void listen(int gen, TargetDataLine line, SpeechRecognizer recognizer, float captureRate) {
        final int bytesPerRead = 4096;            // ~128 ms at 16 kHz
        byte[] raw = new byte[bytesPerRead];
        double ratio = TARGET_RATE / captureRate;

        float utteranceMax = 0f;
        boolean noiseSent = false;
        long lastPartialChange = 0;
        String lastPartial = "";

        while (gen == generation) {
            int n = line.read(raw, 0, raw.length);
            if (n <= 0) {
                continue;
            }
            short[] samples = toShorts(raw, n);
            if (ratio != 1.0) {
                samples = resample(samples, ratio);
            }

            // software gain + volume measurement
            double gain = ClientConfig.INPUT_GAIN.get();
            double sumSq = 0;
            for (int i = 0; i < samples.length; i++) {
                int s = (int) Mth.clamp(samples[i] * gain, Short.MIN_VALUE, Short.MAX_VALUE);
                samples[i] = (short) s;
                sumSq += (double) s * s;
            }
            float rms = samples.length == 0 ? 0f : (float) (Math.sqrt(sumSq / samples.length) / 32768.0);
            ClientState.micLevel = ClientState.micLevel * 0.6f + Math.min(1f, rms * 5f) * 0.4f;
            utteranceMax = Math.max(utteranceMax, rms);

            byte[] pcm = toBytes(samples);
            boolean finished = recognizer.accept(pcm, pcm.length);

            if (finished) {
                String text = extract(recognizer.result(), "text");
                float loudness = loudnessOf(utteranceMax);
                utteranceMax = 0f;
                noiseSent = false;
                lastPartial = "";
                if (!text.isEmpty()) {
                    ClientState.setPhrase(text);
                    VoiceHunterMod.LOGGER.debug("Heard: '{}' (loudness {})", text, loudness);
                    send(text, loudness);
                }
            } else {
                String partial = extract(recognizer.partial(), "partial");
                if (!partial.equals(lastPartial)) {
                    lastPartial = partial;
                    lastPartialChange = System.currentTimeMillis();
                    ClientState.partial = partial;
                }
                // someone is talking but the words are not ready yet: the monster hears a voice
                if (!noiseSent && ClientConfig.SEND_NOISE.get() && rms > ClientConfig.VOICE_THRESHOLD.get()) {
                    noiseSent = true;
                    send("", loudnessOf(utteranceMax));
                }
                if (partial.isEmpty() && System.currentTimeMillis() - lastPartialChange > 2000) {
                    ClientState.partial = "";
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    //  helpers
    // ------------------------------------------------------------------------------------------

    private static float loudnessOf(float rms) {
        return Mth.clamp((rms - 0.015f) / 0.20f, 0f, 1f);
    }

    private static void send(String text, float loudness) {
        Minecraft mc = Minecraft.getInstance();
        mc.execute(() -> {
            if (mc.player != null && mc.getConnection() != null) {
                ModNetwork.sendToServer(new VoiceHeardPayload(text, loudness));
            }
        });
    }

    private static String extract(String json, String field) {
        try {
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            return obj.has(field) ? obj.get(field).getAsString().trim() : "";
        } catch (RuntimeException e) {
            return "";
        }
    }

    /** @return an open line or {@code null} if that sample rate is not supported */
    private static TargetDataLine openMicrophone(float rate) throws LineUnavailableException {
        AudioFormat format = new AudioFormat(rate, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        TargetDataLine line = null;

        String wanted = ClientConfig.MICROPHONE.get().trim().toLowerCase(Locale.ROOT);
        if (!wanted.isEmpty()) {
            for (Mixer.Info mi : AudioSystem.getMixerInfo()) {
                if (!mi.getName().toLowerCase(Locale.ROOT).contains(wanted)) {
                    continue;
                }
                Mixer mixer = AudioSystem.getMixer(mi);
                if (mixer.isLineSupported(info)) {
                    line = (TargetDataLine) mixer.getLine(info);
                    break;
                }
            }
        }
        if (line == null) {
            if (!AudioSystem.isLineSupported(info)) {
                return null;
            }
            line = (TargetDataLine) AudioSystem.getLine(info);
        }
        line.open(format, (int) rate); // buffer of about 0.5 s
        line.start();
        return line;
    }

    private static short[] toShorts(byte[] raw, int n) {
        short[] out = new short[n / 2];
        for (int i = 0; i < out.length; i++) {
            out[i] = (short) ((raw[2 * i + 1] << 8) | (raw[2 * i] & 0xFF));
        }
        return out;
    }

    private static byte[] toBytes(short[] samples) {
        byte[] out = new byte[samples.length * 2];
        for (int i = 0; i < samples.length; i++) {
            out[2 * i] = (byte) samples[i];
            out[2 * i + 1] = (byte) (samples[i] >> 8);
        }
        return out;
    }

    /** Linear-interpolation resampler, good enough for speech (only used when the mic cannot do 16 kHz). */
    private static short[] resample(short[] in, double ratio) {
        int outLen = (int) (in.length * ratio);
        short[] out = new short[outLen];
        for (int i = 0; i < outLen; i++) {
            double pos = i / ratio;
            int i0 = (int) pos;
            int i1 = Math.min(i0 + 1, in.length - 1);
            double frac = pos - i0;
            out[i] = (short) (in[i0] * (1.0 - frac) + in[i1] * frac);
        }
        return out;
    }
}
