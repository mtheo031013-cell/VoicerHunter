package com.voicehunter.client.voice;

import com.voicehunter.VoiceHunterMod;
import com.voicehunter.config.ClientConfig;
import net.minecraft.network.chat.Component;
import net.minecraftforge.fml.loading.FMLPaths;

import javax.annotation.Nullable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.function.IntConsumer;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Finds the offline speech model on disk and, if it is missing and the player allows it,
 * downloads it once (about 31-40 MB) from the official Vosk model list.
 * <p>
 * Everything lives in {@code <game folder>/voicehunter/models}. To install a model by hand, unzip it there.
 */
public final class ModelManager {

    /** Error with a message that can be shown to the player as it is. */
    public static final class ModelException extends Exception {
        private final transient Component component;

        public ModelException(Component component, @Nullable Throwable cause) {
            super(component.getString(), cause);
            this.component = component;
        }

        public Component component() {
            return component;
        }
    }

    private record Spec(String folder, String url, String marker) {
    }

    private static Spec spec() {
        String custom = ClientConfig.CUSTOM_MODEL_DIR.get().trim();
        if (!custom.isEmpty()) {
            return new Spec(custom, ClientConfig.CUSTOM_MODEL_URL.get().trim(), "");
        }
        if ("en".equals(ClientConfig.LANGUAGE.get())) {
            return new Spec("vosk-model-small-en-us-0.15",
                    "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip", "-en");
        }
        return new Spec("vosk-model-small-pt-0.3",
                "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip", "-pt");
    }

    public static Path baseDir() {
        return FMLPaths.GAMEDIR.get().resolve("voicehunter");
    }

    public static Path modelsDir() {
        return baseDir().resolve("models");
    }

    public static Path nativesDir() {
        return baseDir().resolve("natives");
    }

    /**
     * Returns the folder of a ready-to-use model, downloading it first if needed.
     * Blocks, so call it from a worker thread.
     *
     * @param progress receives 0..100 while downloading
     */
    public static Path ensureModel(IntConsumer progress) throws ModelException {
        Spec spec = spec();
        Path models = modelsDir();
        try {
            Files.createDirectories(models);
        } catch (IOException e) {
            throw new ModelException(Component.translatable("gui.voicehunter.error.disk", e.getMessage()), e);
        }

        Path found = findInstalled(models, spec);
        if (found != null) {
            return found;
        }

        if (!ClientConfig.AUTO_DOWNLOAD.get() || spec.url().isEmpty()) {
            throw new ModelException(Component.translatable("gui.voicehunter.error.no_model",
                    models.toAbsolutePath().toString(), spec.folder()), null);
        }

        VoiceHunterMod.LOGGER.info("Downloading speech model from {}", spec.url());
        Path zip = models.resolve(spec.folder() + ".zip.part");
        try {
            download(spec.url(), zip, progress);
            progress.accept(100);
            unzip(zip, models);
        } catch (IOException e) {
            throw new ModelException(Component.translatable("gui.voicehunter.error.download",
                    e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage()), e);
        } finally {
            try {
                Files.deleteIfExists(zip);
            } catch (IOException ignored) {
                // nothing to do
            }
        }

        found = findInstalled(models, spec);
        if (found == null) {
            throw new ModelException(Component.translatable("gui.voicehunter.error.no_model",
                    models.toAbsolutePath().toString(), spec.folder()), null);
        }
        return found;
    }

    /** A Vosk model folder always contains "am" and "conf". */
    private static boolean isModel(Path dir) {
        return Files.isDirectory(dir.resolve("am")) && Files.isDirectory(dir.resolve("conf"));
    }

    @Nullable
    private static Path findInstalled(Path models, Spec spec) {
        Path exact = models.resolve(spec.folder());
        if (isModel(exact)) {
            return exact;
        }
        // a model unzipped by hand may sit inside an extra folder, or have another version number
        try (Stream<Path> children = Files.list(models)) {
            for (Path child : (Iterable<Path>) children::iterator) {
                if (!Files.isDirectory(child)) {
                    continue;
                }
                String name = child.getFileName().toString().toLowerCase(Locale.ROOT);
                boolean matches = spec.marker().isEmpty() ? name.equals(spec.folder().toLowerCase(Locale.ROOT))
                        : name.contains(spec.marker());
                if (!matches) {
                    continue;
                }
                if (isModel(child)) {
                    return child;
                }
                try (Stream<Path> inner = Files.list(child)) {
                    for (Path sub : (Iterable<Path>) inner::iterator) {
                        if (Files.isDirectory(sub) && isModel(sub)) {
                            return sub;
                        }
                    }
                }
            }
        } catch (IOException ignored) {
            // treated as "not installed"
        }
        return null;
    }

    private static void download(String url, Path target, IntConsumer progress) throws IOException {
        HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
        conn.setConnectTimeout(15_000);
        conn.setReadTimeout(30_000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "VoiceHunterMod/" + "1.0");
        int code = conn.getResponseCode();
        if (code != HttpURLConnection.HTTP_OK) {
            throw new IOException("HTTP " + code);
        }
        long total = conn.getContentLengthLong();
        try (InputStream in = conn.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
            byte[] buf = new byte[64 * 1024];
            long done = 0;
            int lastPercent = -1;
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
                done += n;
                if (total > 0) {
                    int percent = (int) (done * 100 / total);
                    if (percent != lastPercent) {
                        lastPercent = percent;
                        progress.accept(Math.min(99, percent));
                    }
                }
            }
        } finally {
            conn.disconnect();
        }
    }

    private static void unzip(Path zip, Path targetDir) throws IOException {
        Path root = targetDir.toAbsolutePath().normalize();
        try (ZipInputStream zin = new ZipInputStream(Files.newInputStream(zip))) {
            ZipEntry entry;
            while ((entry = zin.getNextEntry()) != null) {
                Path out = root.resolve(entry.getName()).normalize();
                if (!out.startsWith(root)) {
                    throw new IOException("Unsafe path in zip: " + entry.getName()); // zip-slip guard
                }
                if (entry.isDirectory()) {
                    Files.createDirectories(out);
                } else {
                    Files.createDirectories(out.getParent());
                    Files.copy(zin, out, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    private ModelManager() {
    }
}
