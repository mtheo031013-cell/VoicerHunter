package com.voicehunter.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.voicehunter.VoiceHunterMod;
import com.voicehunter.client.voice.VoiceEngine;
import com.voicehunter.config.ClientConfig;
import com.voicehunter.entity.HunterState;
import com.voicehunter.entity.Reaction;
import com.voicehunter.entity.VoiceHunterEntity;
import com.voicehunter.voice.Intent;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Small panel in the top-left corner:
 * microphone icon + status, last recognised phrase, monster state and whether it understood.
 */
public final class VoiceHud {

    private static final ResourceLocation MIC_ON = new ResourceLocation(VoiceHunterMod.MODID, "textures/gui/mic_on.png");
    private static final ResourceLocation MIC_OFF = new ResourceLocation(VoiceHunterMod.MODID, "textures/gui/mic_off.png");

    private static final int PANEL_W = 214;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        if (!ClientConfig.SHOW_HUD.get() || mc.options.hideGui || mc.player == null) {
            return;
        }
        Font font = mc.font;
        VoiceEngine engine = VoiceEngine.INSTANCE;
        VoiceEngine.Status status = engine.getStatus();
        long now = System.currentTimeMillis();

        boolean showDetails = status == VoiceEngine.Status.LISTENING
                || now - ClientState.lastPhraseTime < 20_000 || now - ClientState.feedbackTime < 20_000;

        float scale = ClientConfig.HUD_SCALE.get().floatValue();
        g.pose().pushPose();
        g.pose().translate(6, 6, 0);
        g.pose().scale(scale, scale, 1f);

        int panelH = showDetails ? 58 : 22;
        g.fill(0, 0, PANEL_W, panelH, 0x99000000);
        g.fill(0, 0, PANEL_W, 1, status == VoiceEngine.Status.LISTENING ? 0xFFB01818 : 0xFF444444);

        // ---- microphone icon + status ----
        boolean on = status == VoiceEngine.Status.LISTENING;
        RenderSystem.enableBlend();
        g.blit(on ? MIC_ON : MIC_OFF, 3, 3, 16, 16, 0, 0, 32, 32, 32, 32);
        RenderSystem.disableBlend();

        Component statusText = switch (status) {
            case LISTENING -> Component.translatable("gui.voicehunter.mic.on");
            case PREPARING -> engine.getDetail();
            case ERROR -> Component.translatable("gui.voicehunter.mic.error");
            default -> Component.translatable("gui.voicehunter.mic.off",
                    ClientInit.TOGGLE_MIC.getTranslatedKeyMessage());
        };
        int color = switch (status) {
            case LISTENING -> 0xFF5555;
            case ERROR -> 0xFFAA00;
            default -> 0xAAAAAA;
        };
        g.drawString(font, font.plainSubstrByWidth(statusText.getString(), PANEL_W - 60), 24, 7, color, false);

        if (on) {
            // blinking REC dot + input level bar
            if ((now / 500) % 2 == 0) {
                g.fill(PANEL_W - 14, 7, PANEL_W - 8, 13, 0xFFFF2020);
            }
            int bar = (int) (ClientState.micLevel * 36);
            g.fill(PANEL_W - 56, 8, PANEL_W - 56 + 36, 12, 0x66303030);
            g.fill(PANEL_W - 56, 8, PANEL_W - 56 + bar, 12, 0xFF55FF55);
        } else if (status == VoiceEngine.Status.ERROR) {
            g.drawString(font, font.plainSubstrByWidth(engine.getDetail().getString(), PANEL_W - 8), 4, 24, 0xFFAA00, false);
            panelH = Math.max(panelH, 36);
        }

        // ---- details ----
        if (showDetails) {
            String partial = ClientState.partial;
            boolean typing = !partial.isEmpty() && on;
            String phrase = typing ? partial : ClientState.lastPhrase;
            Component heard = Component.translatable("gui.voicehunter.heard");
            g.drawString(font, heard, 5, 23, 0xFFAAAAAA, false);
            int hx = 5 + font.width(heard) + 4;
            String shown = phrase.isEmpty() ? "-" : "\"" + phrase + "\"";
            g.drawString(font, font.plainSubstrByWidth(shown, PANEL_W - hx - 4), hx, 23,
                    typing ? 0xFF999999 : 0xFFFFFFFF, false);

            Component monster = Component.translatable("gui.voicehunter.monster");
            g.drawString(font, monster, 5, 34, 0xFFAAAAAA, false);
            g.drawString(font, monsterStateText(), 5 + font.width(monster) + 4, 34, 0xFFE0A0A0, false);

            Component understood = Component.translatable("gui.voicehunter.understood");
            g.drawString(font, understood, 5, 45, 0xFFAAAAAA, false);
            drawUnderstood(g, font, 5 + font.width(understood) + 4, 45, now);
        }
        g.pose().popPose();
    }

    /** Prefers the real, synced state of the nearest monster; falls back to what the server last told us. */
    private static Component monsterStateText() {
        Minecraft mc = Minecraft.getInstance();
        HunterState state = null;
        if (mc.level != null && mc.player != null) {
            List<VoiceHunterEntity> list = mc.level.getEntitiesOfClass(VoiceHunterEntity.class,
                    mc.player.getBoundingBox().inflate(160.0));
            double best = Double.MAX_VALUE;
            for (VoiceHunterEntity h : list) {
                double d = h.distanceToSqr(mc.player);
                if (d < best) {
                    best = d;
                    state = h.getHunterState();
                }
            }
        }
        if (state == null) {
            state = ClientState.feedbackState;
        }
        if (state == null) {
            return Component.translatable("gui.voicehunter.state.unknown");
        }
        return Component.translatable("gui.voicehunter.state." + state.key());
    }

    private static void drawUnderstood(GuiGraphics g, Font font, int x, int y, long now) {
        Reaction r = ClientState.reaction;
        if (r == null || now - ClientState.feedbackTime > 20_000) {
            g.drawString(font, "-", x, y, 0xFF777777, false);
            return;
        }
        @Nullable Intent intent = ClientState.understood;
        String key = "gui.voicehunter.reaction." + r.key();
        Component text = intent == null ? Component.translatable(key)
                : Component.translatable(key, Component.translatable("gui.voicehunter.intent." + intent.key()));
        int color = switch (r) {
            case OBEYED, MOOD -> 0xFF55FF55;
            case MISHEARD -> 0xFFFFAA00;
            case IGNORED -> 0xFFFF7755;
            default -> 0xFFAAAAAA;
        };
        String mark = switch (r) {
            case OBEYED, MOOD, MISHEARD, IGNORED -> "✔ ";
            default -> "✖ ";
        };
        g.drawString(font, font.plainSubstrByWidth(mark + text.getString(), PANEL_W - x - 4), x, y, color, false);
    }

    private VoiceHud() {
    }
}
