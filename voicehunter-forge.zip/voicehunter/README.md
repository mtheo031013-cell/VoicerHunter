# The Voice Hunter — Minecraft Java 1.20.1 (Forge)

Horror mod: a tall monster **listens to your real microphone** and reacts to what you say.
Speech recognition is **offline** ([Vosk](https://alphacephei.com/vosk/)); only the recognised *text* is sent to the game, never audio.

## Build and install
Requirements: JDK 17+ (Gradle downloads a JDK 17 automatically if needed) and internet on the first build.

```
./gradlew build          # Windows: gradlew.bat build
```
The mod is `build/libs/voicehunter-1.0.0.jar` (Vosk and its native libraries for Windows/Linux/macOS are merged inside).
Put it in `mods/` of a **Forge 20.4.x / Minecraft 1.20.1** instance. For development: `./gradlew runClient`.

## First run
1. Join a world and press **V** (configurable in Controls). A red microphone icon and "Microphone ACTIVE" appear.
2. First use downloads the speech model (~31 MB, Portuguese; `language = "en"` in `config/voicehunter-client.toml` for English) to `<game>/voicehunter/models`.
   Offline? Download `vosk-model-small-pt-0.3.zip` from https://alphacephei.com/vosk/models and unzip it into that folder.
3. The first time you enter a world a cardboard **Hunter Box** is placed on the ground a few blocks in front of you. **Right-click it: the monster comes out.** Then talk to it.
   More boxes: craft one (paper x8 around a spider eye), take it from the creative menu, or `/voicehunter box` (operators). `/voicehunter summon` skips the box.
   Config: `boxAtFirstJoin` (default true) and `autoSpawn` (monster also appears by itself, default false).

Wrong microphone? `/voicemic list`, then `/voicemic use <part of name>` (`/voicemic default` to reset).
The microphone is **off by default**, only listens while the HUD shows it as active, and is closed when you leave the world.

## What it understands (Portuguese and English)
| You say | Monster |
|---|---|
| vem aqui | comes to you |
| para | stops for a moment |
| corre | runs |
| me segue | follows you |
| vai embora | moves away |
| fica parado | stays frozen like a statue |
| me procura | searches where you last spoke (your voice gives you away) |
| dorme / acorda | sleeps (it may be faking) / wakes |
| vem me pegar | hunts you |
| oi, bom garoto / idiota, vou te matar / socorro | tone: trust, anger, aggression |

Matching is fuzzy (accents, small recognition errors, "não vem aqui" = go away). Loudness matters: whispers attract it, shouting angers it.

## Personality
Each monster is born with its own traits (obedience, mischief, curiosity) and mood (trust, aggression). It may **ignore** you,
**mishear** you (the HUD shows what it *thought* it heard), **pretend to obey** and betray you when you look away, or get **angry**.
It also acts alone: watches from afar, stalks only while you are not looking, vanishes and reappears behind you.

## Horror
Sounds only you hear (whispers behind you, footsteps, door knocks, heartbeat), distant silent lightning, torches snuffed out,
Darkness pulses, closing fog, vignette, heartbeat and camera shake as it approaches. It cannot be killed by normal means: at low health it retreats, heals and returns.

## HUD
Microphone icon/state + input level, last recognised phrase (live partial text in grey), monster state, and whether it understood.

## Config
`config/voicehunter-common.toml` (spawn, scares, aggression, disobedience, damage; set `allowAggression=false` for a scare-only mode) and
`config/voicehunter-client.toml` (microphone, gain, language, HUD, effects).

## Project layout
`voice/` pure-Java phrase parser (no Minecraft classes) · `entity/` monster, personality, states · `server/` voice brain, haunt director, commands ·
`client/` HUD, effects, renderer · `client/voice/` microphone + Vosk · `network/` payloads · `tools/generate_assets.py` regenerates textures and sounds.

Licence: MIT. Vosk: Apache 2.0.

## Build on GitHub (no local setup)
Push this folder to a GitHub repository. The workflow in `.github/workflows/build.yml` builds it automatically:
open the **Actions** tab, pick the latest run and download the **voicehunter-jar** artifact (the `.jar` to put in `mods/`).
If the build fails, open the run log: the error line tells exactly what to fix.
